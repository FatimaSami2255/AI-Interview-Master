"use client";
/* eslint-disable react-hooks/purity */

import React, { useEffect, useState, useRef, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CyberCard } from "@/components/CyberCard";
import { CyberButton } from "@/components/CyberButton";
import { getRandomQuestionsForQuiz, saveQuizResult } from "@/lib/storage";
import { Question } from "@/lib/types";
import { ShieldAlertIcon } from "@/components/SvgIcons";

// Inner component that handles search params
const QuizPlayContent: React.FC = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const difficultyParam = searchParams ? searchParams.get("difficulty") || "All" : "All";

  // Configuration and details
  const [codename, setCodename] = useState("");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");

  // Quiz progression state
  const [currentIndex, setCurrentIndex] = useState(0);
  const currentIndexRef = useRef(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const answersRef = useRef<(number | null)[]>([]);
  const advancingRef = useRef(false);

  // Time tracking
  const [secondsRemaining, setSecondsRemaining] = useState(30);
  const [quizStartTime, setQuizStartTime] = useState<number>(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  function playSynthesizedBeep(freq: number, duration: number, type: OscillatorType = "sine") {
    if (typeof window === "undefined") return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.02, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {}
  }

  // Timer controllers
  function stopTimer() {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }

  function advanceNext(customAnswer: number | null) {
    if (advancingRef.current) return;
    advancingRef.current = true;

    const idx = currentIndexRef.current;
    const total = questions.length;

    // Record answer in both state and ref
    const updatedAnswers = [...answersRef.current];
    updatedAnswers[idx] = customAnswer;
    answersRef.current = updatedAnswers;
    setAnswers(updatedAnswers);
    setSelectedOption(null);

    if (idx + 1 >= total) {
      stopTimer();
      submitQuizResults(updatedAnswers);
    } else {
      const nextIdx = idx + 1;
      setCurrentIndex(nextIdx);
      currentIndexRef.current = nextIdx;
      setSecondsRemaining(30);
      setTimeout(() => {
        advancingRef.current = false;
        startTimerForQuestion();
      }, 50);
    }
  }

  function handleTimeOut() {
    playSynthesizedBeep(180, 0.25, "sawtooth");
    advanceNext(null);
  }

  function startTimerForQuestion() {
    stopTimer();
    setSecondsRemaining(30);
    const questionIndex = currentIndexRef.current;
    timerRef.current = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (advancingRef.current) return prev;
        if (prev <= 1) {
          stopTimer();
          // Only time out if we're still on the same question
          if (currentIndexRef.current === questionIndex) {
            handleTimeOut();
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }

  async function initializeQuiz() {
    setLoading(true);
    setErrorMsg("");
    try {
      const selectedQuestions = await getRandomQuestionsForQuiz(difficultyParam);
      if (selectedQuestions.length === 0) {
        setErrorMsg("DATABASE DEVOID OF QUESTIONS MATCHING DIFFICULTY RANGE");
        return;
      }
      setQuestions(selectedQuestions);
      currentIndexRef.current = 0;
      const initAnswers = new Array(selectedQuestions.length).fill(null);
      setAnswers(initAnswers);
      answersRef.current = initAnswers;
      setQuizStartTime(Date.now());
      startTimerForQuestion();
    } catch {
      setErrorMsg("DATABASE NODE OFFLINE");
    } finally {
      setLoading(false);
    }
  }

  // Option selection
  function handleOptionSelect(optionIndex: number) {
    setSelectedOption(optionIndex);
    playSynthesizedBeep(850, 0.05);
  }

  function handleSkipQuestion() {
    playSynthesizedBeep(350, 0.1, "triangle");
    advanceNext(null);
  }

  function handleConfirmAnswer() {
    if (selectedOption === null) return;
    advanceNext(selectedOption);
  }

  // Submit results
  async function submitQuizResults(finalAnswers: (number | null)[]) {
    setLoading(true);
    try {
      const durationSeconds = Math.round((Date.now() - quizStartTime) / 1000);
      let correctCount = 0;
      questions.forEach((q, idx) => {
        if (finalAnswers[idx] === q.correctOptionIndex) {
          correctCount++;
        }
      });
      const percentageScore = Math.round((correctCount / questions.length) * 100);
      const resultObj = {
        candidateName: codename,
        score: percentageScore,
        totalQuestions: questions.length,
        correctAnswersCount: correctCount,
        timeTakenSeconds: durationSeconds,
      };
      const savedResult = await saveQuizResult(resultObj);
      if (typeof window !== "undefined") {
        const attemptDetails = {
          questions,
          answers: finalAnswers,
          correctCount,
          durationSeconds,
          score: percentageScore,
        };
        sessionStorage.setItem("cyber_current_attempt_details", JSON.stringify(attemptDetails));
      }
      playSynthesizedBeep(1200, 0.3);
      router.push(`/quiz/results?id=${savedResult.id}`);
    } catch {
      setErrorMsg("TRANSMISSION FAULT: UNABLE TO POST QUIZ RESULTS");
    } finally {
      setLoading(false);
    }
  }

  // Initialize profile & retrieve questions
  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedName = localStorage.getItem("cyber_candidate_name");
      if (!storedName) {
        router.push("/quiz");
        return;
      }
      setTimeout(() => {
        setCodename(storedName);
      }, 0);
    }
    const timeoutId = setTimeout(() => {
      initializeQuiz();
    }, 0);

    return () => {
      clearTimeout(timeoutId);
      stopTimer();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Loader UI
  if (loading) {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "calc(100vh - 73px)",
          gap: "24px",
        }}
      >
        <div className="cyber-loader" />
        <span
          className="cyber-label"
          style={{ fontSize: "0.85rem", letterSpacing: "2px", animation: "pulse-cyan 1.5s infinite" }}
        >
          CONNECTING TO NEURAL TESTING CORES...
        </span>
      </div>
    );
  }

  // Error UI
  if (errorMsg) {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "calc(100vh - 73px)",
          padding: "24px",
        }}
      >
        <CyberCard
          glowColor="pink"
          title="GRID MALFUNCTION"
          subtitle="SYSTEM CONFLICT DETECTED"
          style={{ maxWidth: "450px", textAlign: "center" }}
        >
          <div style={{ color: "var(--neon-pink)", marginBottom: "16px" }}>
            <ShieldAlertIcon size={48} style={{ margin: "0 auto" }} />
          </div>
          <p style={{ fontFamily: "var(--font-mono)", fontSize: "0.9rem", color: "var(--text-secondary)", marginBottom: "24px" }}>
            {errorMsg}
          </p>
          <CyberButton variant="danger" onClick={() => router.push("/quiz")}>
            RETURN TO LOBBY
          </CyberButton>
        </CyberCard>
      </div>
    );
  }

  const currentQuestion = questions[currentIndex] ?? null;
  const progressPercent = Math.round(((currentIndex + 1) / Math.max(questions.length, 1)) * 100);

  // Animate timer circle variables
  const timerRadius = 24;
  const timerCircumference = 2 * Math.PI * timerRadius;
  const timerStrokeDashoffset = timerCircumference - (secondsRemaining / 30) * timerCircumference;

  // Decide timer color based on severity
  const timerColor =
    secondsRemaining > 15
      ? "var(--neon-cyan)"
      : secondsRemaining > 5
      ? "var(--neon-yellow)"
      : "var(--neon-pink)";

  return (
    <div
      className="cyber-container"
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "calc(100vh - 100px)",
        paddingBottom: "60px",
      }}
    >
      <div style={{ maxWidth: "700px", width: "100%" }}>
        {/* Progress HUD bar */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            fontFamily: "var(--font-mono)",
            fontSize: "0.8rem",
            color: "var(--text-secondary)",
            marginBottom: "12px",
          }}
        >
          <span>EVALUATION NODE: {currentIndex + 1} / {questions.length}</span>
          <span className="cyber-label" style={{ color: "var(--neon-cyan)" }}>
            SECTOR: {currentQuestion?.category?.toUpperCase() || "N/A"}
          </span>
        </div>

        {/* Global Progress Bar container */}
        <div
          style={{
            width: "100%",
            height: "4px",
            background: "rgba(255,255,255,0.05)",
            borderRadius: "2px",
            marginBottom: "24px",
            overflow: "hidden",
            position: "relative",
          }}
        >
          <div
            style={{
              width: `${progressPercent}%`,
              height: "100%",
              background: "linear-gradient(90deg, var(--neon-purple), var(--neon-cyan))",
              boxShadow: "var(--glow-cyan)",
              transition: "width 0.3s ease-in-out",
            }}
          />
        </div>

        {/* Question Container Card */}
        <CyberCard
          glowColor={secondsRemaining > 10 ? "cyan" : "pink"}
          scanline={false}
          style={{ padding: "30px" }}
        >
          {/* Top Panel: Timer + Difficulty Badge */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "24px",
              borderBottom: "1px solid rgba(255,255,255,0.05)",
              paddingBottom: "16px",
            }}
          >
            <span
              className={`cyber-badge ${(currentQuestion?.difficulty ?? "").toLowerCase()}`}
              style={{ padding: "4px 10px" }}
            >
              DIFFICULTY: {currentQuestion?.difficulty}
            </span>

            {/* Glowing SVG Timer Circle */}
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: "1.1rem",
                  fontWeight: "bold",
                  color: timerColor,
                  textShadow: secondsRemaining <= 5 ? `0 0 8px ${timerColor}` : "none",
                }}
              >
                {secondsRemaining}s
              </span>
              <svg width="60" height="60" style={{ transform: "rotate(-90deg)" }}>
                <circle
                  cx="30"
                  cy="30"
                  r={timerRadius}
                  fill="transparent"
                  stroke="rgba(255, 255, 255, 0.05)"
                  strokeWidth="4"
                />
                <circle
                  cx="30"
                  cy="30"
                  r={timerRadius}
                  fill="transparent"
                  stroke={timerColor}
                  strokeWidth="4"
                  strokeDasharray={timerCircumference}
                  strokeDashoffset={timerStrokeDashoffset}
                  style={{
                    transition: "stroke-dashoffset 1s linear, stroke 0.3s",
                    filter: secondsRemaining <= 5 ? "drop-shadow(0px 0px 3px var(--neon-pink))" : "none",
                  }}
                />
              </svg>
            </div>
          </div>

          {/* Question Text in futuristic style */}
          <div style={{ minHeight: "80px", marginBottom: "32px" }}>
            <h3
              style={{
                fontSize: "1.25rem",
                fontWeight: 500,
                lineHeight: "1.5",
                color: "#fff",
                letterSpacing: "0.5px",
              }}
            >
              {currentQuestion?.text}
            </h3>
          </div>

          {/* Multiple choice options */}
          <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
            {(currentQuestion?.options ?? []).map((option, idx) => {
              const isSelected = selectedOption === idx;
              const optionLetter = String.fromCharCode(65 + idx);

              return (
                <div
                  key={idx}
                  onClick={() => handleOptionSelect(idx)}
                  style={{
                    padding: "16px 20px",
                    background: isSelected ? "rgba(0, 242, 254, 0.08)" : "rgba(5, 5, 8, 0.7)",
                    border: `1px solid ${isSelected ? "var(--neon-cyan)" : "rgba(255, 255, 255, 0.06)"}`,
                    borderRadius: "6px",
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: "16px",
                    boxShadow: isSelected ? "var(--glow-cyan)" : "none",
                    transition: "all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1)",
                  }}
                  onMouseEnter={(e) => {
                    if (!isSelected) {
                      e.currentTarget.style.borderColor = "rgba(0, 242, 254, 0.4)";
                      e.currentTarget.style.background = "rgba(0, 242, 254, 0.02)";
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isSelected) {
                      e.currentTarget.style.borderColor = "rgba(255, 255, 255, 0.06)";
                      e.currentTarget.style.background = "rgba(5, 5, 8, 0.7)";
                    }
                  }}
                >
                  {/* Indicator sphere */}
                  <div
                    style={{
                      width: "20px",
                      height: "20px",
                      borderRadius: "50%",
                      border: `2px solid ${isSelected ? "var(--neon-cyan)" : "var(--text-muted)"}`,
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      background: isSelected ? "var(--neon-cyan)" : "transparent",
                      boxShadow: isSelected ? "0 0 5px var(--neon-cyan)" : "none",
                      transition: "all 0.15s",
                    }}
                  >
                    {isSelected && (
                      <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#050508" }} />
                    )}
                  </div>

                  <div style={{ flex: 1 }}>
                    <span
                      style={{
                        fontFamily: "var(--font-mono)",
                        fontWeight: "bold",
                        marginRight: "8px",
                        color: isSelected ? "var(--neon-cyan)" : "var(--text-secondary)",
                      }}
                    >
                      {optionLetter}.
                    </span>
                    <span style={{ color: "#fff", fontSize: "0.95rem" }}>{option}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action Footer Button row */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginTop: "36px",
              borderTop: "1px solid rgba(255,255,255,0.05)",
              paddingTop: "24px",
            }}
          >
            <CyberButton variant="secondary" size="medium" onClick={handleSkipQuestion}>
              BYPASS_NODE [SKIP]
            </CyberButton>

            <CyberButton
              variant={selectedOption === null ? "secondary" : "primary"}
              size="medium"
              onClick={handleConfirmAnswer}
              disabled={selectedOption === null}
            >
              {currentIndex === questions.length - 1 ? "FINALIZE_GRID" : "CONFIRM // NEXT"}
            </CyberButton>
          </div>
        </CyberCard>
      </div>
    </div>
  );
};

export default function QuizPlay() {
  return (
    <Suspense
      fallback={
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "calc(100vh - 73px)",
            gap: "24px",
          }}
        >
          <div className="cyber-loader" />
          <span className="cyber-label" style={{ fontSize: "0.85rem", letterSpacing: "2px" }}>
            SYNCHRONIZING EXAM GRIDS...
          </span>
        </div>
      }
    >
      <QuizPlayContent />
    </Suspense>
  );
}
