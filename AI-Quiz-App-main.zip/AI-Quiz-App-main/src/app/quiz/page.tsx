"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { CyberCard } from "@/components/CyberCard";
import { CyberButton } from "@/components/CyberButton";
import { getQuizResults, getQuestions, loginCandidate } from "@/lib/storage";
import { QuizResult } from "@/lib/types";
import { ClockIcon, PlayIcon, InfoIcon, LockIcon } from "@/components/SvgIcons";

export default function StudentLobby() {
  const router = useRouter();

  // Login form
  const [codename, setCodename] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  const [difficulty, setDifficulty] = useState("All");
  const [dbQuestionCount, setDbQuestionCount] = useState(0);

  // Leaderboard and diagnostic states
  const [leaderboard, setLeaderboard] = useState<QuizResult[]>([]);
  const [personalStats, setPersonalStats] = useState({
    attempts: 0,
    highScore: 0,
    avgTime: 0,
  });

  const [loading, setLoading] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);
  const [activeCodename, setActiveCodename] = useState("");

  const loadLobbyData = async () => {
    setLoading(true);
    try {
      const q = await getQuestions();
      setDbQuestionCount(q.length);

      const results = await getQuizResults();

      const sortedLeaderboard = [...results].sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        return a.timeTakenSeconds - b.timeTakenSeconds;
      });
      setLeaderboard(sortedLeaderboard);

      if (typeof window !== "undefined") {
        const storedName = localStorage.getItem("cyber_candidate_name") || "";
        if (storedName) {
          setActiveCodename(storedName);
          setLoggedIn(true);

          const personal = results.filter(
            (r) => r.candidateName.toLowerCase() === storedName.toLowerCase()
          );
          if (personal.length > 0) {
            setPersonalStats({
              attempts: personal.length,
              highScore: Math.max(...personal.map((p) => p.score)),
              avgTime: Math.round(
                personal.reduce((sum, curr) => sum + curr.timeTakenSeconds, 0) / personal.length
              ),
            });
          }
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setTimeout(() => loadLobbyData(), 0);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");

    const trimmed = codename.trim().toUpperCase();
    if (!trimmed || trimmed.length < 3) {
      setLoginError("CODENAME MUST HAVE AT LEAST 3 SYMBOLS");
      return;
    }
    if (trimmed.length > 15) {
      setLoginError("CODENAME MUST NOT EXCEED 15 SYMBOLS");
      return;
    }
    if (!password) {
      setLoginError("PASSWORD IS REQUIRED");
      return;
    }

    try {
      const name = await loginCandidate(trimmed, password);
      localStorage.setItem("cyber_candidate_name", name);
      setActiveCodename(name);
      setLoggedIn(true);
      setPassword("");
      setCodename("");
      // Reload to get personal stats
      await loadLobbyData();
    } catch (err: any) {
      setLoginError(err.message || "INVALID CREDENTIALS");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("cyber_candidate_name");
    setLoggedIn(false);
    setActiveCodename("");
    setPersonalStats({ attempts: 0, highScore: 0, avgTime: 0 });
  };

  const handleLaunchQuiz = () => {
    if (dbQuestionCount < 10) {
      setLoginError(`INSUFFICIENT DATABASE NODE COUNT (${dbQuestionCount}/10 required)`);
      return;
    }
    router.push(`/quiz/play?difficulty=${difficulty}`);
  };

  return (
    <div className="cyber-container" style={{ paddingBottom: "80px" }}>
      <div style={{ textAlign: "center", margin: "24px 0 40px" }}>
        <span className="cyber-label" style={{ fontSize: "0.75rem", textShadow: "var(--glow-cyan)" }}>
          [ SIMULATED GRID WORKSTATION ]
        </span>
        <h2 style={{ fontSize: "2.2rem", marginTop: "8px", textTransform: "uppercase" }}>
          CANDIDATE EXAM ROOM
        </h2>
        <p style={{ color: "var(--text-secondary)", fontSize: "0.95rem", marginTop: "8px" }}>
          Authenticate your network identification profile to enter the testing grid.
        </p>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
          gap: "32px",
          alignItems: "start",
        }}
      >
        {/* PROFILE / LOGIN */}
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          {!loggedIn ? (
            <CyberCard
              glowColor="cyan"
              title="CANDIDATE AUTHENTICATION"
              subtitle="ENTER YOUR CREDENTIALS"
              scanline={true}
            >
              <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
                {loginError && (
                  <div style={{ padding:"10px", background:"rgba(255,0,127,0.1)", border:"1px solid var(--neon-pink)",
                    color:"var(--neon-pink)", borderRadius:"4px", fontFamily:"var(--font-mono)", fontSize:"0.8rem" }}>
                    {loginError}
                  </div>
                )}

                <div>
                  <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"8px" }}>
                    CANDIDATE CODENAME
                  </label>
                  <input type="text" className="cyber-input"
                    style={{ textTransform:"uppercase", fontFamily:"var(--font-mono)" }}
                    value={codename}
                    onChange={(e) => setCodename(e.target.value.replace(/[^a-zA-Z0-9_]/g, ""))}
                    placeholder="ENTER_NAME" maxLength={15} />
                </div>

                <div>
                  <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"8px" }}>
                    PASSWORD
                  </label>
                  <input type="password" className="cyber-input"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••" />
                </div>

                <CyberButton variant="primary" style={{ width:"100%", padding:"14px" }} type="submit">
                  <span style={{ display:"inline-flex", alignItems:"center", gap:"8px" }}>
                    <LockIcon size={16} />
                    AUTHENTICATE
                  </span>
                </CyberButton>
              </form>

              <div style={{ marginTop:"16px", padding:"12px", background:"rgba(0,0,0,0.2)", borderRadius:"4px",
                border:"1px solid rgba(157,78,221,0.15)", textAlign:"center" }}>
                <p style={{ color:"var(--text-muted)", fontSize:"0.75rem", fontFamily:"var(--font-mono)" }}>
                  Don't have an account? Contact your administrator to register.
                </p>
              </div>
            </CyberCard>
          ) : (
            <>
              <CyberCard glowColor="green" title="SESSION ACTIVE" subtitle={`CANDIDATE: ${activeCodename}`}>
                {loginError && (
                  <div style={{ padding:"10px", marginBottom:"16px", background:"rgba(255,0,127,0.1)", border:"1px solid var(--neon-pink)",
                    color:"var(--neon-pink)", borderRadius:"4px", fontFamily:"var(--font-mono)", fontSize:"0.8rem" }}>
                    {loginError}
                  </div>
                )}
                <div style={{ display:"flex", flexDirection:"column", gap:"20px" }}>
                  {personalStats.attempts > 0 && (
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"12px", textAlign:"center" }}>
                      <div>
                        <span className="cyber-label" style={{ fontSize:"0.6rem", color:"var(--text-secondary)", display:"block" }}>ATTEMPTS</span>
                        <span style={{ fontSize:"1.5rem", fontFamily:"var(--font-mono)", fontWeight:"bold" }}>{personalStats.attempts}</span>
                      </div>
                      <div>
                        <span className="cyber-label" style={{ fontSize:"0.6rem", color:"var(--text-secondary)", display:"block" }}>HIGH_SCORE</span>
                        <span style={{ fontSize:"1.5rem", fontFamily:"var(--font-mono)", fontWeight:"bold", color:"var(--neon-green)" }}>{personalStats.highScore}%</span>
                      </div>
                      <div>
                        <span className="cyber-label" style={{ fontSize:"0.6rem", color:"var(--text-secondary)", display:"block" }}>AVG_SPEED</span>
                        <span style={{ fontSize:"1.5rem", fontFamily:"var(--font-mono)", fontWeight:"bold" }}>{personalStats.avgTime}s</span>
                      </div>
                    </div>
                  )}

                  {/* Difficulty + Launch controls */}
                  <div>
                    <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"8px" }}>
                      TEST_DIFFICULTY_PARAMETER
                    </label>
                    <select className="cyber-select" value={difficulty}
                      onChange={(e) => setDifficulty(e.target.value)} style={{ marginBottom:"16px", width:"100%" }}>
                      <option value="All">ALL DIFFICULTY LEVELS</option>
                      <option value="Easy">EASY [DIAGNOSTIC]</option>
                      <option value="Medium">MEDIUM [STANDARD]</option>
                      <option value="Hard">HARD [NETRUNNER]</option>
                    </select>
                  </div>

                  <CyberButton variant="primary" style={{ width:"100%", padding:"14px" }} onClick={handleLaunchQuiz}>
                    <span style={{ display:"inline-flex", alignItems:"center", gap:"8px" }}>
                      <PlayIcon size={16} />
                      INITIALIZE QUIZ_SEQUENCE
                    </span>
                  </CyberButton>

                  <CyberButton variant="secondary" size="small" onClick={handleLogout}>
                    DISCONNECT SESSION
                  </CyberButton>
                </div>
              </CyberCard>
            </>
          )}

          {/* INSTRUCTIONS */}
          <CyberCard glowColor="yellow" style={{ padding:"16px 20px" }}>
            <div style={{ display:"flex", gap:"12px", alignItems:"flex-start" }}>
              <div style={{ color:"var(--neon-yellow)", marginTop:"2px" }}><InfoIcon size={20} /></div>
              <div style={{ fontSize:"0.85rem", lineHeight:"1.5" }}>
                <strong style={{ color:"var(--neon-yellow)" }}>EXAM SPECIFICATIONS:</strong>
                <ul style={{ paddingLeft:"16px", marginTop:"6px", display:"flex", flexDirection:"column", gap:"4px" }}>
                  <li>Quiz pulls 10 random questions matching configuration parameters.</li>
                  <li>A 30-second automated timer is assigned to each question.</li>
                  <li>Skipping or running out of time records 0 points for that node.</li>
                  <li>Leaderboard records are ranked by accuracy, then speed.</li>
                </ul>
              </div>
            </div>
          </CyberCard>
        </div>

        {/* GLOBAL LEADERBOARD */}
        <CyberCard glowColor="purple" title="GLOBAL GRID LEADERBOARD" subtitle="TOP LOGGED EXAM RUNNERS" style={{ width:"100%" }}>
          {loading ? (
            <div style={{ display:"flex", justifyContent:"center", padding:"40px" }}><div className="cyber-loader" /></div>
          ) : leaderboard.length === 0 ? (
            <div style={{ textAlign:"center", padding:"40px", color:"var(--text-muted)", fontFamily:"var(--font-mono)" }}>
              [ LEADERBOARD INACTIVE - ZERO RUNS RECORDED ]
            </div>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
              {leaderboard.slice(0, 10).map((entry, idx) => {
                const isTopThree = idx < 3;
                const badges = ["CORE_AGENT", "ELITE_RUNNER", "OPERATIVE"];
                const rankColor = idx === 0 ? "var(--neon-yellow)" : idx === 1 ? "#d1d5db" : idx === 2 ? "#b45309" : "var(--text-secondary)";
                return (
                  <div key={entry.id}
                    style={{ display:"flex", alignItems:"center", justifyContent:"space-between",
                      padding:"12px 16px", background:"rgba(0,0,0,0.25)",
                      border:`1px solid ${isTopThree ? "rgba(157,78,221,0.2)" : "rgba(255,255,255,0.03)"}`, borderRadius:"6px",
                      transition:"all 0.2s" }}
                    onMouseEnter={(e) => { e.currentTarget.style.borderColor = "rgba(0,242,254,0.3)"; e.currentTarget.style.transform = "translateX(4px)"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.borderColor = isTopThree ? "rgba(157,78,221,0.2)" : "rgba(255,255,255,0.03)"; e.currentTarget.style.transform = "translateX(0)"; }}>
                    <div style={{ display:"flex", alignItems:"center", gap:"12px" }}>
                      <span style={{ fontFamily:"var(--font-mono)", fontSize:"1.1rem", fontWeight:"bold", color:rankColor, minWidth:"24px", textAlign:"center" }}>#{idx+1}</span>
                      <div>
                        <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                          <span style={{ fontSize:"0.95rem", color:"#fff", fontWeight:"bold" }}>{entry.candidateName.toUpperCase()}</span>
                          {isTopThree && (
                            <span className="cyber-badge" style={{ fontSize:"0.55rem", padding:"1px 4px",
                              background: idx===0 ? "rgba(255,251,0,0.1)" : "rgba(157,78,221,0.1)",
                              color: idx===0 ? "var(--neon-yellow)" : "var(--neon-purple)",
                              border:`1px solid ${idx===0 ? "rgba(255,251,0,0.3)" : "rgba(157,78,221,0.3)"}` }}>
                              {badges[idx]}
                            </span>
                          )}
                        </div>
                        <div style={{ display:"flex", alignItems:"center", gap:"10px", marginTop:"4px", fontSize:"0.75rem", color:"var(--text-secondary)", fontFamily:"var(--font-mono)" }}>
                          <span style={{ display:"flex", alignItems:"center", gap:"3px" }}><ClockIcon size={10} />{entry.timeTakenSeconds}s</span>
                          <span>•</span>
                          <span>{entry.correctAnswersCount} / {entry.totalQuestions} CORRECT</span>
                        </div>
                      </div>
                    </div>
                    <span style={{ fontFamily:"var(--font-mono)", fontSize:"1.2rem", fontWeight:"bold",
                      color: entry.score >= 80 ? "var(--neon-green)" : entry.score >= 50 ? "var(--neon-yellow)" : "var(--neon-pink)" }}>
                      {entry.score}%
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </CyberCard>
      </div>
    </div>
  );
}
