"use client";

import React, { useEffect, useState, Suspense } from "react";
import { useRouter } from "next/navigation";
import { CyberCard } from "@/components/CyberCard";
import { CyberButton } from "@/components/CyberButton";
import { Question } from "@/lib/types";
import { AwardIcon, ClockIcon, InfoIcon } from "@/components/SvgIcons";

interface AttemptDetails {
  questions: Question[];
  answers: (number | null)[];
  correctCount: number;
  durationSeconds: number;
  score: number;
}

const ResultsContent: React.FC = () => {
  const router = useRouter();

  const [attempt, setAttempt] = useState<AttemptDetails | null>(null);
  const [animatedScore, setAnimatedScore] = useState(0);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = sessionStorage.getItem("cyber_current_attempt_details");
      if (stored) {
        const data: AttemptDetails = JSON.parse(stored);
        
        // Defer state update to satisfy React 19 strict hook check
        const timeoutId = setTimeout(() => {
          setAttempt(data);
        }, 0);

        // Count up animation
        let start = 0;
        const end = data.score;
        if (end === 0) {
          return () => clearTimeout(timeoutId);
        }
        const duration = 1200; // ms
        const increment = Math.max(1, Math.round(end / 40));
        const timer = setInterval(() => {
          start += increment;
          if (start >= end) {
            setAnimatedScore(end);
            clearInterval(timer);
          } else {
            setAnimatedScore(start);
          }
        }, duration / (end / increment));

        return () => {
          clearTimeout(timeoutId);
          clearInterval(timer);
        };
      } else {
        router.push("/quiz");
      }
    }
  }, [router]);

  if (!attempt) {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "calc(100vh - 73px)",
          gap: "20px",
        }}
      >
        <div className="cyber-loader" />
        <span className="cyber-label" style={{ fontSize: "0.8rem" }}>
          RETRIEVING EXAM RUN DETAILS...
        </span>
      </div>
    );
  }

  // Rank categorization
  const getRankDetails = (score: number) => {
    if (score === 100) {
      return {
        title: "ARCH-NETRUNNER",
        grade: "S-CLASS",
        color: "var(--neon-green)",
        shadow: "var(--glow-green)",
      };
    } else if (score >= 80) {
      return {
        title: "CYBER-KNIGHT",
        grade: "A-CLASS",
        color: "var(--neon-cyan)",
        shadow: "var(--glow-cyan)",
      };
    } else if (score >= 60) {
      return {
        title: "GRID-OPERATIVE",
        grade: "B-CLASS",
        color: "var(--neon-yellow)",
        shadow: "var(--glow-yellow)",
      };
    } else if (score >= 40) {
      return {
        title: "SYS_INITIATE",
        grade: "C-CLASS",
        color: "var(--neon-purple)",
        shadow: "var(--glow-purple)",
      };
    } else {
      return {
        title: "CODE-MONKEY",
        grade: "F-CLASS",
        color: "var(--neon-pink)",
        shadow: "var(--glow-pink)",
      };
    }
  };

  const rank = getRankDetails(attempt.score);

  // SVG parameters for score gauge
  const radius = 60;
  const strokeWidth = 8;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (animatedScore / 100) * circumference;

  return (
    <div className="cyber-container" style={{ paddingBottom: "100px" }}>
      {/* Page Header */}
      <div style={{ textAlign: "center", margin: "24px 0 40px" }}>
        <span className="cyber-label" style={{ textShadow: rank.shadow, color: rank.color }}>
          [ EXAM TERMINATED // EVALUATION READY ]
        </span>
        <h2 style={{ fontSize: "2.2rem", marginTop: "8px", textTransform: "uppercase" }}>
          DEBRIEFING DOSSIER
        </h2>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
          gap: "32px",
          alignItems: "start",
          marginBottom: "40px",
        }}
      >
        {/* SCORE SUMMARY MODULE */}
        <CyberCard glowColor={attempt.score >= 60 ? "cyan" : "pink"} title="COGNITIVE PERFORMANCE" scanline={true}>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "24px",
              padding: "16px 0",
            }}
          >
            {/* Circular Gauge */}
            <div style={{ position: "relative", width: "150px", height: "150px" }}>
              <svg width="150" height="150" style={{ transform: "rotate(-90deg)" }}>
                <circle
                  cx="75"
                  cy="75"
                  r={radius}
                  fill="transparent"
                  stroke="rgba(255, 255, 255, 0.03)"
                  strokeWidth={strokeWidth}
                />
                <circle
                  cx="75"
                  cy="75"
                  r={radius}
                  fill="transparent"
                  stroke={rank.color}
                  strokeWidth={strokeWidth}
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  style={{
                    transition: "stroke-dashoffset 0.1s ease-out",
                    filter: `drop-shadow(0 0 6px ${rank.color})`,
                  }}
                />
              </svg>
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: "150px",
                  height: "150px",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <span
                  style={{
                    fontFamily: "var(--font-mono)",
                    fontSize: "2.5rem",
                    fontWeight: "bold",
                    color: "#fff",
                  }}
                >
                  {animatedScore}%
                </span>
                <span className="cyber-label" style={{ fontSize: "0.6rem", color: "var(--text-secondary)" }}>
                  ACCURACY
                </span>
              </div>
            </div>

            {/* Rank Designation */}
            <div style={{ textAlign: "center" }}>
              <span
                className="cyber-label"
                style={{
                  fontSize: "1.3rem",
                  color: rank.color,
                  textShadow: rank.shadow,
                  fontWeight: 900,
                  letterSpacing: "2px",
                  display: "block",
                }}
              >
                {rank.title}
              </span>
              <span
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: "0.85rem",
                  color: "var(--text-secondary)",
                  marginTop: "6px",
                  display: "block",
                }}
              >
                SECURITY CLASSIFICATION: {rank.grade}
              </span>
            </div>
          </div>
        </CyberCard>

        {/* DIAGNOSTIC METRICS MODULE */}
        <CyberCard glowColor="purple" title="GRID METRIC LOGS">
          <div style={{ display: "flex", flexDirection: "column", gap: "20px", padding: "10px 0" }}>
            <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid rgba(255,255,255,0.04)", paddingBottom: "12px" }}>
              <span style={{ color: "var(--text-secondary)", display: "inline-flex", alignItems: "center", gap: "8px" }}>
                <AwardIcon size={16} />
                Correct Answers:
              </span>
              <span style={{ fontFamily: "var(--font-mono)", fontWeight: "bold", color: "#fff" }}>
                {attempt.correctCount} / {attempt.questions.length} Nodes
              </span>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid rgba(255,255,255,0.04)", paddingBottom: "12px" }}>
              <span style={{ color: "var(--text-secondary)", display: "inline-flex", alignItems: "center", gap: "8px" }}>
                <ClockIcon size={16} />
                Total Time Elapsed:
              </span>
              <span style={{ fontFamily: "var(--font-mono)", fontWeight: "bold", color: "#fff" }}>
                {attempt.durationSeconds} Seconds
              </span>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid rgba(255,255,255,0.04)", paddingBottom: "12px" }}>
              <span style={{ color: "var(--text-secondary)", display: "inline-flex", alignItems: "center", gap: "8px" }}>
                <InfoIcon size={16} />
                Avg Response Speed:
              </span>
              <span style={{ fontFamily: "var(--font-mono)", fontWeight: "bold", color: "var(--neon-cyan)" }}>
                {attempt.questions.length > 0 ? (attempt.durationSeconds / attempt.questions.length).toFixed(1) : 0}s / question
              </span>
            </div>
          </div>

          <div style={{ display: "flex", gap: "12px", marginTop: "24px" }}>
            <CyberButton variant="primary" style={{ flex: 1 }} onClick={() => router.push("/quiz")}>
              RELOAD_GRID
            </CyberButton>
            <CyberButton variant="secondary" style={{ flex: 1 }} onClick={() => router.push("/")}>
              TERMINATE
            </CyberButton>
          </div>
        </CyberCard>
      </div>

      {/* DETAILED QUESTION RESPONSE AUDIT */}
      <h3 style={{ textTransform: "uppercase", fontSize: "1.3rem", marginBottom: "20px", borderBottom: "1px solid rgba(255,255,255,0.05)", paddingBottom: "8px" }}>
        EXAM AUDIT LOGS
      </h3>

      <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
        {attempt.questions.map((q, idx) => {
          const selectedIdx = attempt.answers[idx];
          const isCorrect = selectedIdx === q.correctOptionIndex;
          const isSkipped = selectedIdx === null;

          return (
            <CyberCard
              key={q.id}
              glowColor={isSkipped ? "yellow" : isCorrect ? "green" : "pink"}
              title={`NODE #${idx + 1}: ${q.category.toUpperCase()}`}
              subtitle={`DIFFICULTY: ${q.difficulty.toUpperCase()}`}
            >
              <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                {/* Question */}
                <p style={{ fontSize: "1.1rem", fontWeight: "bold", color: "#fff", lineHeight: "1.4" }}>
                  {q.text}
                </p>

                {/* Options grid */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "12px" }}>
                  {q.options.map((opt, optIdx) => {
                    const selectedThis = selectedIdx === optIdx;
                    const correctThis = q.correctOptionIndex === optIdx;
                    
                    let bg = "rgba(0,0,0,0.15)";
                    let border = "rgba(255,255,255,0.04)";
                    let color = "var(--text-secondary)";
                    let badge = null;

                    if (correctThis) {
                      bg = "rgba(57, 255, 20, 0.05)";
                      border = "rgba(57, 255, 20, 0.4)";
                      color = "var(--neon-green)";
                      badge = "[CORRECT]";
                    } else if (selectedThis) {
                      bg = "rgba(255, 0, 127, 0.05)";
                      border = "rgba(255, 0, 127, 0.4)";
                      color = "var(--neon-pink)";
                      badge = "[CHOSEN]";
                    }

                    return (
                      <div
                        key={optIdx}
                        style={{
                          padding: "12px 16px",
                          background: bg,
                          border: `1px solid ${border}`,
                          color: color,
                          borderRadius: "6px",
                          fontSize: "0.9rem",
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <div>
                          <strong style={{ marginRight: "6px" }}>{String.fromCharCode(65 + optIdx)}.</strong>
                          {opt}
                        </div>
                        {badge && (
                          <span style={{ fontSize: "0.65rem", fontFamily: "var(--font-mono)", fontWeight: "bold" }}>
                            {badge}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Explanation Block */}
                <div
                  style={{
                    background: "rgba(5,5,8,0.7)",
                    border: `1px solid ${isSkipped ? "rgba(255,251,0,0.15)" : isCorrect ? "rgba(57,255,20,0.15)" : "rgba(255,0,127,0.15)"}`,
                    borderRadius: "6px",
                    padding: "16px",
                    fontSize: "0.85rem",
                    lineHeight: "1.5",
                  }}
                >
                  <div style={{ display: "flex", gap: "8px", alignItems: "center", marginBottom: "8px" }}>
                    <span
                      className="cyber-label"
                      style={{
                        fontSize: "0.7rem",
                        color: isSkipped ? "var(--neon-yellow)" : isCorrect ? "var(--neon-green)" : "var(--neon-pink)",
                      }}
                    >
                      {isSkipped
                        ? "DIAGNOSIS: ATTEMPT SKIPPED // BYPASS INITIATED"
                        : isCorrect
                        ? "DIAGNOSIS: LOGIC COMPATIBLE // SYSTEM ALIGNED"
                        : "DIAGNOSIS: LOGIC CONFLICT // MALFORMED SEQUENCE"}
                    </span>
                  </div>
                  <p style={{ color: "var(--text-secondary)" }}>
                    <strong style={{ color: "#fff" }}>EXPLANATION: </strong>
                    {q.explanation || "No explanation provided for this data node."}
                  </p>
                </div>
              </div>
            </CyberCard>
          );
        })}
      </div>
    </div>
  );
};

export default function QuizResults() {
  return (
    <Suspense
      fallback={
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "calc(100vh - 73px)",
            gap: "24px",
          }}
        >
          <div className="cyber-loader" />
          <span className="cyber-label" style={{ fontSize: "0.85rem", letterSpacing: "2px" }}>
            COMPILING DIAGNOSTIC CHARTS...
          </span>
        </div>
      }
    >
      <ResultsContent />
    </Suspense>
  );
}
