"use client";

import React, { useEffect, useState } from "react";
import { CyberCard } from "@/components/CyberCard";
import { CyberButton } from "@/components/CyberButton";
import {
  getQuestions,
  saveQuestion,
  deleteQuestion,
  getQuizResults,
  resetToDefaults,
  deleteCandidateResults,
  checkAdminExists,
  registerAdmin,
  loginAdmin,
  getCandidates,
  createCandidate,
  deleteCandidate,
} from "@/lib/storage";
import { Question, DifficultyLevel, QuizResult } from "@/lib/types";
import { TrashIcon, EditIcon, LockIcon, UserIcon, KeyIcon } from "@/components/SvgIcons";

const generateRandomId = () => "q_" + Math.random().toString(36).substring(2, 11);

type AdminTab = "dashboard" | "questions" | "candidates" | "settings";

export default function AdminPage() {
  // ── Auth state ──────────────────────────────────────────────────────────────
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [adminExists, setAdminExists] = useState<boolean | null>(null);

  // Login form
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // Register form
  const [regUsername, setRegUsername] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regConfirm, setRegConfirm] = useState("");
  const [regError, setRegError] = useState("");

  // ── DB ──────────────────────────────────────────────────────────────────────
  const [questions, setQuestions] = useState<Question[]>([]);
  const [results, setResults] = useState<QuizResult[]>([]);
  const [dbLoading, setDbLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<AdminTab>("dashboard");

  // ── Question form ───────────────────────────────────────────────────────────
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formText, setFormText] = useState("");
  const [formOptions, setFormOptions] = useState<[string, string, string, string]>(["", "", "", ""]);
  const [formCorrectIndex, setFormCorrectIndex] = useState<number>(0);
  const [formDifficulty, setFormDifficulty] = useState<DifficultyLevel>("Medium");
  const [formCategory, setFormCategory] = useState("");
  const [formExplanation, setFormExplanation] = useState("");
  const [formError, setFormError] = useState("");

  // ── Candidate management ────────────────────────────────────────────────────
  const [candidates, setCandidates] = useState<{ name: string; isActive: boolean; createdAt: string }[]>([]);
  const [newCandName, setNewCandName] = useState("");
  const [newCandPassword, setNewCandPassword] = useState("");
  const [candError, setCandError] = useState("");
  const [candMsg, setCandMsg] = useState("");

  // ─────────────────────────────────────────────────────────────────────────────
  useEffect(() => {
    checkAdminExists()
      .then((exists) => setAdminExists(exists))
      .catch(() => setAdminExists(false))
      .finally(() => setLoading(false));
  }, []);

  const loadData = async () => {
    setDbLoading(true);
    try {
      const [q, r] = await Promise.all([getQuestions(), getQuizResults()]);
      setQuestions(q);
      setResults(r);
    } catch (err) {
      console.error(err);
    } finally {
      setDbLoading(false);
    }
  };

  const loadCandidates = async () => {
    try {
      const c = await getCandidates();
      setCandidates(c);
    } catch {
      console.error("Failed to load candidates");
    }
  };

  useEffect(() => {
    if (!isAuthenticated) return;
    setTimeout(() => { loadData(); loadCandidates(); }, 0);
  }, [isAuthenticated]);

  // ─── Admin Registration ─────────────────────────────────────────────────────
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError("");
    if (!regUsername.trim() || !regPassword) {
      setRegError("Username and password required");
      return;
    }
    if (regPassword.length < 4) {
      setRegError("Password must be at least 4 characters");
      return;
    }
    if (regPassword !== regConfirm) {
      setRegError("Passwords do not match");
      return;
    }
    try {
      await registerAdmin(regUsername.trim(), regPassword);
      setIsAuthenticated(true);
    } catch (err: any) {
      setRegError(err.message || "Registration failed");
    }
  };

  // ─── Admin Login ────────────────────────────────────────────────────────────
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    if (!loginUsername.trim() || !loginPassword) {
      setLoginError("Username and password required");
      return;
    }
    try {
      await loginAdmin(loginUsername.trim(), loginPassword);
      setIsAuthenticated(true);
      setLoginUsername("");
      setLoginPassword("");
    } catch (err: any) {
      setLoginError(err.message || "Login failed");
    }
  };

  // ─── Question CRUD ────────────────────────────────────────────────────────
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");
    if (!formText.trim()) return setFormError("Question text required");
    if (formOptions.some((o) => !o.trim())) return setFormError("All 4 options required");
    if (!formCategory.trim()) return setFormError("Category required");

    const q: Question = {
      id: editingId || generateRandomId(),
      text: formText,
      options: [...formOptions] as [string, string, string, string],
      correctOptionIndex: formCorrectIndex,
      difficulty: formDifficulty,
      category: formCategory,
      explanation: formExplanation,
    };
    setDbLoading(true);
    try { await saveQuestion(q); await loadData(); resetForm(); }
    catch { setFormError("Injection failed: Database offline"); }
    finally { setDbLoading(false); }
  };

  const resetForm = () => {
    setFormText(""); setFormOptions(["", "", "", ""]); setFormCorrectIndex(0);
    setFormDifficulty("Medium"); setFormCategory(""); setFormExplanation("");
    setEditingId(null); setFormError("");
  };

  const handleEditClick = (q: Question) => {
    setEditingId(q.id); setFormText(q.text);
    setFormOptions([...q.options] as [string, string, string, string]);
    setFormCorrectIndex(q.correctOptionIndex); setFormDifficulty(q.difficulty);
    setFormCategory(q.category); setFormExplanation(q.explanation || "");
    setActiveTab("questions");
    setTimeout(() => window.scrollTo({ top: 0, behavior: "smooth" }), 50);
  };

  const handleDeleteClick = async (id: string) => {
    if (!confirm("PURGE ITEM FROM SYSTEM STORAGE?")) return;
    setDbLoading(true);
    try { await deleteQuestion(id); await loadData(); }
    catch (err) { console.error(err); }
    finally { setDbLoading(false); }
  };

  const handleResetSystem = async () => {
    if (!confirm("RESTORE SYSTEM DEFAULTS? Clears all questions, results, and candidates.")) return;
    setDbLoading(true);
    try { await resetToDefaults(); await loadData(); resetForm(); }
    catch (err) { console.error(err); }
    finally { setDbLoading(false); }
  };

  // ─── Candidate CRUD ───────────────────────────────────────────────────────
  const handleCreateCandidate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCandError("");
    setCandMsg("");
    const name = newCandName.trim().toUpperCase().replace(/[^A-Z0-9_]/g, "");
    if (!name || name.length < 3) {
      setCandError("Name must be at least 3 characters (A-Z, 0-9, _)");
      return;
    }
    if (newCandPassword.length < 4) {
      setCandError("Password must be at least 4 characters");
      return;
    }
    try {
      await createCandidate(name, newCandPassword);
      setCandMsg(`Candidate ${name} created successfully`);
      setNewCandName("");
      setNewCandPassword("");
      await loadCandidates();
    } catch (err: any) {
      setCandError(err.message || "Failed to create candidate");
    }
  };

  const handleDeleteCandidate = async (name: string) => {
    if (!confirm(`PURGE CANDIDATE ACCOUNT: ${name}? This also removes all their results.`)) return;
    setDbLoading(true);
    try {
      await deleteCandidate(name);
      await deleteCandidateResults(name);
      await loadData();
      await loadCandidates();
    } catch (err) { console.error(err); }
    finally { setDbLoading(false); }
  };

  // ─── Computed metrics ──────────────────────────────────────────────────────
  const easyCount   = questions.filter((q) => q.difficulty === "Easy").length;
  const mediumCount = questions.filter((q) => q.difficulty === "Medium").length;
  const hardCount   = questions.filter((q) => q.difficulty === "Hard").length;
  const averageScore = results.length
    ? Math.round(results.reduce((a, r) => a + r.score, 0) / results.length) : 0;
  const passCount    = results.filter((r) => r.score >= 60).length;
  const passRate     = results.length ? Math.round((passCount / results.length) * 100) : 0;

  const buckets = [
    { label: "0-20%",   count: results.filter((r) => r.score <= 20).length, color: "var(--neon-pink)" },
    { label: "21-40%",  count: results.filter((r) => r.score > 20 && r.score <= 40).length, color: "#ff6b35" },
    { label: "41-60%",  count: results.filter((r) => r.score > 40 && r.score <= 60).length, color: "var(--neon-yellow)" },
    { label: "61-80%",  count: results.filter((r) => r.score > 60 && r.score <= 80).length, color: "var(--neon-cyan)" },
    { label: "81-100%", count: results.filter((r) => r.score > 80).length, color: "var(--neon-green)" },
  ];
  const maxBucket = Math.max(...buckets.map((b) => b.count), 1);

  // ═══════════════════════════════════════════════════════════════════════════
  // AUTH GATE
  // ═══════════════════════════════════════════════════════════════════════════
  if (loading) {
    return (
      <div style={{ display:"flex", justifyContent:"center", alignItems:"center", minHeight:"calc(100vh - 73px)" }}>
        <div className="cyber-loader" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div style={{ display:"flex", justifyContent:"center", alignItems:"center", minHeight:"calc(100vh - 73px)", padding:"24px" }}>
        <CyberCard glowColor="purple" title="ADMIN GATEWAY" subtitle="AUTHENTICATION REQUIRED"
          style={{ width:"100%", maxWidth:"420px" }} scanline={true}>

          <div style={{ textAlign:"center", marginBottom:"20px" }}>
            <div style={{ width:"48px", height:"48px", borderRadius:"50%", background:"rgba(157,78,221,0.1)",
              border:"1px solid var(--neon-purple)", display:"flex", justifyContent:"center",
              alignItems:"center", margin:"0 auto 12px", boxShadow:"var(--glow-purple)", color:"var(--neon-purple)" }}>
              <LockIcon size={24} />
            </div>

            {adminExists === false ? (
              <>
                <p style={{ color:"var(--neon-yellow)", fontSize:"0.85rem", fontFamily:"var(--font-mono)", marginBottom:"8px" }}>
                  NO ADMIN ACCOUNT FOUND
                </p>
                <p style={{ color:"var(--text-secondary)", fontSize:"0.85rem", marginBottom:"16px" }}>
                  Create the first administrator account to initialize the system.
                </p>
                <form onSubmit={handleRegister} style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
                  {regError && (
                    <div style={{ padding:"8px", background:"rgba(255,0,127,0.1)", border:"1px solid var(--neon-pink)",
                      color:"var(--neon-pink)", borderRadius:"4px", fontFamily:"var(--font-mono)", fontSize:"0.75rem" }}>
                      {regError}
                    </div>
                  )}
                  <div>
                    <label className="cyber-label" style={{ fontSize:"0.7rem", display:"block", marginBottom:"4px", textAlign:"left" }}>USERNAME</label>
                    <input type="text" className="cyber-input" value={regUsername}
                      onChange={(e) => setRegUsername(e.target.value)} placeholder="admin" />
                  </div>
                  <div>
                    <label className="cyber-label" style={{ fontSize:"0.7rem", display:"block", marginBottom:"4px", textAlign:"left" }}>PASSWORD</label>
                    <input type="password" className="cyber-input" value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)} placeholder="••••••" />
                  </div>
                  <div>
                    <label className="cyber-label" style={{ fontSize:"0.7rem", display:"block", marginBottom:"4px", textAlign:"left" }}>CONFIRM PASSWORD</label>
                    <input type="password" className="cyber-input" value={regConfirm}
                      onChange={(e) => setRegConfirm(e.target.value)} placeholder="••••••" />
                  </div>
                  <CyberButton variant="primary" type="submit" style={{ marginTop:"8px", width:"100%" }}>
                    CREATE ADMIN ACCOUNT
                  </CyberButton>
                </form>
              </>
            ) : (
              <>
                <p style={{ color:"var(--text-secondary)", fontSize:"0.85rem", marginBottom:"16px" }}>
                  ENTER SYSTEM CREDENTIALS FOR ROOT PERMISSIONS
                </p>
                <form onSubmit={handleLogin} style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
                  {loginError && (
                    <div style={{ padding:"8px", background:"rgba(255,0,127,0.1)", border:"1px solid var(--neon-pink)",
                      color:"var(--neon-pink)", borderRadius:"4px", fontFamily:"var(--font-mono)", fontSize:"0.75rem" }}>
                      {loginError}
                    </div>
                  )}
                  <div>
                    <label className="cyber-label" style={{ fontSize:"0.7rem", display:"block", marginBottom:"4px", textAlign:"left" }}>USERNAME</label>
                    <input type="text" className="cyber-input" value={loginUsername}
                      onChange={(e) => setLoginUsername(e.target.value)} placeholder="Enter username" />
                  </div>
                  <div>
                    <label className="cyber-label" style={{ fontSize:"0.7rem", display:"block", marginBottom:"4px", textAlign:"left" }}>PASSWORD</label>
                    <input type="password" className="cyber-input" value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)} placeholder="••••••" />
                  </div>
                  <CyberButton variant="primary" type="submit" style={{ marginTop:"8px", width:"100%" }}>
                    AUTHENTICATE
                  </CyberButton>
                </form>
              </>
            )}
          </div>
        </CyberCard>
      </div>
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ADMIN PANEL (Authenticated)
  // ═══════════════════════════════════════════════════════════════════════════
  const candidateMap = results.reduce<Record<string, QuizResult[]>>((acc, r) => {
    const key = r.candidateName.toUpperCase();
    if (!acc[key]) acc[key] = [];
    acc[key].push(r);
    return acc;
  }, {});

  return (
    <div className="cyber-container" style={{ paddingBottom:"80px" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center",
        flexWrap:"wrap", gap:"16px", marginBottom:"24px",
        borderBottom:"1px solid rgba(255,255,255,0.05)", paddingBottom:"16px" }}>
        <div>
          <span className="cyber-label">[ SECURE WORKSPACE ]</span>
          <h2 style={{ fontSize:"1.8rem" }}>ADMIN TERMINAL</h2>
        </div>
        <div style={{ display:"flex", gap:"12px" }}>
          <CyberButton variant="danger" size="small" onClick={handleResetSystem}>RESET_STORE</CyberButton>
          <CyberButton variant="secondary" size="small" onClick={() => setIsAuthenticated(false)}>DISCONNECT</CyberButton>
        </div>
      </div>

      <div style={{ display:"flex", gap:"8px", flexWrap:"wrap", marginBottom:"32px" }}>
        {(["dashboard","questions","candidates","settings"] as AdminTab[]).map((tab) => {
          const labels: Record<AdminTab,string> = {
            dashboard:"DASHBOARD", questions:"QUESTION BANK",
            candidates:"CANDIDATES", settings:"SETTINGS"
          };
          const active = activeTab === tab;
          return (
            <button key={tab} onClick={() => setActiveTab(tab)} style={{
              fontFamily:"var(--font-display)", fontSize:"0.75rem", letterSpacing:"1.5px",
              padding:"8px 16px", background: active ? "rgba(0,242,254,0.1)" : "transparent",
              border:`1px solid ${active ? "var(--neon-cyan)" : "rgba(255,255,255,0.08)"}`,
              color: active ? "var(--neon-cyan)" : "var(--text-secondary)",
              borderRadius:"4px", cursor:"pointer",
              boxShadow: active ? "var(--glow-cyan)" : "none",
              transition:"all 0.2s" }}>
              {labels[tab]}
            </button>
          );
        })}
      </div>

      {/* ══════════════════════════════════════════════════════════════════════
          TAB: DASHBOARD (unchanged)
      ══════════════════════════════════════════════════════════════════════ */}
      {activeTab === "dashboard" && (
        <div style={{ display:"flex", flexDirection:"column", gap:"32px" }}>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(200px,1fr))", gap:"16px" }}>
            {[
              { label:"TOTAL_QUESTIONS", value:questions.length, sub:`${easyCount}E / ${mediumCount}M / ${hardCount}H`, color:"var(--neon-cyan)" },
              { label:"TOTAL_SESSIONS",  value:results.length,   sub:"EXAM RUNS",       color:"var(--neon-purple)" },
              { label:"AVERAGE_SCORE",   value:`${averageScore}%`,sub:"OVERALL",        color:"var(--neon-yellow)" },
              { label:"PASS_RATE",       value:`${passRate}%`,   sub:"≥60% THRESHOLD",  color:"var(--neon-green)" },
            ].map((s) => (
              <CyberCard key={s.label} glowColor="cyan" style={{ padding:"16px" }}>
                <span className="cyber-label" style={{ fontSize:"0.7rem", color:"var(--text-secondary)", display:"block" }}>{s.label}</span>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"baseline", marginTop:"8px" }}>
                  <span style={{ fontSize:"2rem", fontFamily:"var(--font-mono)", fontWeight:"bold", color:s.color }}>{s.value}</span>
                  <span style={{ fontSize:"0.7rem", color:"var(--text-muted)", fontFamily:"var(--font-mono)" }}>{s.sub}</span>
                </div>
              </CyberCard>
            ))}
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(320px,1fr))", gap:"24px" }}>
            <CyberCard glowColor="cyan" title="SCORE DISTRIBUTION" subtitle="RESULT FREQUENCY PER RANGE">
              {results.length === 0 ? (
                <div style={{ textAlign:"center", padding:"32px", color:"var(--text-muted)", fontFamily:"var(--font-mono)" }}>[ NO DATA ]</div>
              ) : (
                <div style={{ display:"flex", flexDirection:"column", gap:"14px", padding:"8px 0" }}>
                  {buckets.map((b) => {
                    const pct = Math.round((b.count / maxBucket) * 100);
                    return (
                      <div key={b.label}>
                        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"6px" }}>
                          <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.75rem", color:b.color }}>{b.label}</span>
                          <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.75rem", color:"var(--text-secondary)" }}>{b.count} sessions</span>
                        </div>
                        <div style={{ width:"100%", height:"10px", background:"rgba(255,255,255,0.04)", borderRadius:"5px", overflow:"hidden" }}>
                          <div style={{ width:`${pct}%`, height:"100%", background:b.color, boxShadow:`0 0 8px ${b.color}`, borderRadius:"5px", transition:"width 0.6s ease-out" }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CyberCard>

            <CyberCard glowColor="purple" title="DIFFICULTY BREAKDOWN" subtitle="QUESTION POOL COMPOSITION">
              <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:"32px", padding:"16px 0" }}>
                <svg width="130" height="130" viewBox="0 0 42 42" style={{ flexShrink:0 }}>
                  {(() => {
                    const segments = [
                      { count: easyCount,   color: "var(--neon-green)",  label: "Easy"   },
                      { count: mediumCount, color: "var(--neon-yellow)", label: "Medium" },
                      { count: hardCount,   color: "var(--neon-pink)",   label: "Hard"   },
                    ];
                    const total = easyCount + mediumCount + hardCount || 1;
                    const r = 15.9; const cx = 21; const cy = 21;
                    const circ = 2 * Math.PI * r;
                    let offset = 0;
                    return segments.map((s, i) => {
                      const pct = s.count / total;
                      const dash = pct * circ;
                      const gap  = circ - dash;
                      const el = (
                        <circle key={i} cx={cx} cy={cy} r={r} fill="transparent"
                          stroke={s.color} strokeWidth="5"
                          strokeDasharray={`${dash} ${gap}`}
                          strokeDashoffset={-offset}
                          style={{ transform:"rotate(-90deg)", transformOrigin:"center",
                            filter:`drop-shadow(0 0 3px ${s.color})` }} />
                      );
                      offset += dash;
                      return el;
                    });
                  })()}
                  <circle cx="21" cy="21" r="10" fill="rgba(5,5,8,0.9)" />
                  <text x="21" y="24" textAnchor="middle" fontSize="5"
                    fill="#fff" fontFamily="monospace">{questions.length}</text>
                </svg>
                <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
                  {[
                    { label:"EASY",   count:easyCount,   color:"var(--neon-green)"  },
                    { label:"MEDIUM", count:mediumCount, color:"var(--neon-yellow)" },
                    { label:"HARD",   count:hardCount,   color:"var(--neon-pink)"   },
                  ].map((l) => (
                    <div key={l.label} style={{ display:"flex", alignItems:"center", gap:"10px" }}>
                      <span style={{ width:"10px", height:"10px", borderRadius:"2px", background:l.color, boxShadow:`0 0 5px ${l.color}`, flexShrink:0 }} />
                      <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.8rem", color:"var(--text-secondary)" }}>
                        {l.label}: <strong style={{ color:"#fff" }}>{l.count}</strong>
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </CyberCard>

            <CyberCard glowColor="green" title="TOP CANDIDATES" subtitle="HIGHEST SCORES (ALL TIME)" style={{ gridColumn:"1 / -1" }}>
              {results.length === 0 ? (
                <div style={{ textAlign:"center", padding:"24px", color:"var(--text-muted)", fontFamily:"var(--font-mono)" }}>[ NO SESSIONS RECORDED ]</div>
              ) : (
                <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
                  {[...results].sort((a,b) => b.score - a.score).slice(0,6).map((r,i) => {
                    const bar = r.score;
                    const rowColor = r.score >= 80 ? "var(--neon-green)" : r.score >= 60 ? "var(--neon-cyan)" : r.score >= 40 ? "var(--neon-yellow)" : "var(--neon-pink)";
                    return (
                      <div key={r.id} style={{ display:"flex", alignItems:"center", gap:"12px" }}>
                        <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.75rem", color:"var(--text-muted)", minWidth:"20px" }}>#{i+1}</span>
                        <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.85rem", color:"#fff", minWidth:"120px" }}>{r.candidateName.toUpperCase()}</span>
                        <div style={{ flex:1, height:"8px", background:"rgba(255,255,255,0.04)", borderRadius:"4px", overflow:"hidden" }}>
                          <div style={{ width:`${bar}%`, height:"100%", background:rowColor, boxShadow:`0 0 6px ${rowColor}`, borderRadius:"4px", transition:"width 0.5s ease" }} />
                        </div>
                        <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.85rem", color:rowColor, minWidth:"42px", textAlign:"right" }}>{r.score}%</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </CyberCard>
          </div>

          <CyberCard glowColor="green" title="CANDIDATE LOG SHEETS" subtitle="EXAM RECORDS & DIAGNOSTICS">
            {results.length === 0 ? (
              <div style={{ textAlign:"center", padding:"32px", color:"var(--text-muted)", fontFamily:"var(--font-mono)" }}>[ LOG REGISTER EMPTY ]</div>
            ) : (
              <div style={{ overflowX:"auto" }}>
                <table style={{ width:"100%", borderCollapse:"collapse", fontFamily:"var(--font-mono)", fontSize:"0.85rem", textAlign:"left" }}>
                  <thead>
                    <tr style={{ borderBottom:"1px solid rgba(255,255,255,0.08)" }}>
                      {["CODENAME","ACCURACY","CORRECT","DURATION","TIMESTAMP"].map((h) => (
                        <th key={h} style={{ padding:"12px", color:"var(--neon-green)" }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {results.map((r) => (
                      <tr key={r.id} style={{ borderBottom:"1px solid rgba(255,255,255,0.04)" }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(57,255,20,0.03)")}
                        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                        <td style={{ padding:"12px", color:"#fff", fontWeight:"bold" }}>{r.candidateName}</td>
                        <td style={{ padding:"12px", color: r.score >= 80 ? "var(--neon-green)" : r.score >= 50 ? "var(--neon-yellow)" : "var(--neon-pink)", fontWeight:"bold" }}>{r.score}%</td>
                        <td style={{ padding:"12px", color:"var(--text-secondary)" }}>{r.correctAnswersCount} / {r.totalQuestions}</td>
                        <td style={{ padding:"12px", color:"var(--text-secondary)" }}>{r.timeTakenSeconds}s</td>
                        <td style={{ padding:"12px", color:"var(--text-muted)" }}>{new Date(r.timestamp).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CyberCard>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          TAB: QUESTIONS (unchanged)
      ══════════════════════════════════════════════════════════════════════ */}
      {activeTab === "questions" && (
        <div style={{ display:"flex", flexDirection:"column", gap:"32px" }}>
          <CyberCard glowColor={editingId ? "yellow" : "cyan"}
            title={editingId ? "EDIT DATA NODE" : "INJECT NEW DATA NODE"}
            subtitle={editingId ? "UPDATE EXISTING EVALUATION" : "ADD NEW QUESTION TO REGISTRY"}>
            <form onSubmit={handleFormSubmit} style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
              {formError && (
                <div style={{ padding:"10px", background:"rgba(255,0,127,0.1)", border:"1px solid var(--neon-pink)",
                  color:"var(--neon-pink)", borderRadius:"4px", fontFamily:"var(--font-mono)", fontSize:"0.8rem" }}>
                  {formError}
                </div>
              )}
              <div>
                <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"6px" }}>QUESTION_TEXT</label>
                <textarea className="cyber-input" style={{ resize:"vertical", minHeight:"80px" }}
                  value={formText} onChange={(e) => setFormText(e.target.value)} placeholder="Enter question text here..." />
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))", gap:"12px" }}>
                {formOptions.map((opt, i) => (
                  <div key={i}>
                    <label className="cyber-label" style={{ fontSize:"0.7rem", display:"block", marginBottom:"4px", color:"var(--text-secondary)" }}>OPTION_{String.fromCharCode(65+i)}</label>
                    <input type="text" className="cyber-input" value={opt}
                      onChange={(e) => { const n=[...formOptions]; n[i]=e.target.value; setFormOptions(n as [string,string,string,string]); }}
                      placeholder={`Option ${String.fromCharCode(65+i)}`} />
                  </div>
                ))}
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))", gap:"16px" }}>
                <div>
                  <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"6px" }}>CORRECT_ANSWER</label>
                  <select className="cyber-select" value={formCorrectIndex} onChange={(e) => setFormCorrectIndex(Number(e.target.value))}>
                    {["OPTION A","OPTION B","OPTION C","OPTION D"].map((l,i) => <option key={i} value={i}>{l}</option>)}
                  </select>
                </div>
                <div>
                  <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"6px" }}>DIFFICULTY_LEVEL</label>
                  <select className="cyber-select" value={formDifficulty} onChange={(e) => setFormDifficulty(e.target.value as DifficultyLevel)}>
                    <option value="Easy">EASY</option><option value="Medium">MEDIUM</option><option value="Hard">HARD</option>
                  </select>
                </div>
                <div>
                  <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"6px" }}>CATEGORY</label>
                  <input type="text" className="cyber-input" value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)} placeholder="e.g. AI, Cryptography" />
                </div>
              </div>
              <div>
                <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"6px" }}>EXPLANATION</label>
                <textarea className="cyber-input" style={{ resize:"vertical", minHeight:"60px" }}
                  value={formExplanation} onChange={(e) => setFormExplanation(e.target.value)}
                  placeholder="Explain why the answer is correct..." />
              </div>
              <div style={{ display:"flex", gap:"12px", justifyContent:"flex-end", marginTop:"8px" }}>
                {editingId && <CyberButton variant="secondary" onClick={resetForm} type="button">CANCEL_EDIT</CyberButton>}
                <CyberButton variant={editingId ? "yellow" : "success"} type="submit" disabled={dbLoading}>
                  {editingId ? "COMPILE_UPDATE" : "INJECT_NODE"}
                </CyberButton>
              </div>
            </form>
          </CyberCard>

          <CyberCard glowColor="purple" title="DATABASE REGISTRY" subtitle={`TOTAL: ${questions.length} NODES`}>
            {dbLoading && questions.length === 0 ? (
              <div style={{ display:"flex", justifyContent:"center", padding:"40px" }}><div className="cyber-loader" /></div>
            ) : (
              <div style={{ display:"flex", flexDirection:"column", gap:"16px", maxHeight:"600px", overflowY:"auto", paddingRight:"8px" }}>
                {questions.map((q, idx) => (
                  <div key={q.id} style={{ border:"1px solid rgba(255,255,255,0.04)", background:"rgba(0,0,0,0.2)",
                    borderRadius:"6px", padding:"16px", display:"flex", justifyContent:"space-between", gap:"16px" }}
                    onMouseEnter={(e) => (e.currentTarget.style.borderColor = "rgba(157,78,221,0.2)")}
                    onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.04)")}>
                    <div style={{ flex:1, display:"flex", flexDirection:"column", gap:"8px" }}>
                      <div style={{ display:"flex", alignItems:"center", gap:"8px", flexWrap:"wrap" }}>
                        <span className="cyber-badge easy" style={{ fontSize:"0.65rem", padding:"2px 6px" }}>{q.category}</span>
                        <span className={`cyber-badge ${q.difficulty.toLowerCase()}`} style={{ fontSize:"0.65rem", padding:"2px 6px" }}>{q.difficulty}</span>
                      </div>
                      <h4 style={{ fontSize:"1rem", color:"#fff" }}>{idx+1}. {q.text}</h4>
                      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))", gap:"6px", marginTop:"4px" }}>
                        {q.options.map((opt, oi) => (
                          <div key={oi} style={{ fontSize:"0.8rem",
                            color: oi === q.correctOptionIndex ? "var(--neon-green)" : "var(--text-secondary)",
                            display:"flex", alignItems:"center", gap:"6px" }}>
                            <span style={{ width:"6px", height:"6px", borderRadius:"50%",
                              background: oi === q.correctOptionIndex ? "var(--neon-green)" : "rgba(255,255,255,0.1)", flexShrink:0 }} />
                            <strong>{String.fromCharCode(65+oi)}:</strong> {opt}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div style={{ display:"flex", flexDirection:"column", gap:"8px", justifyContent:"center" }}>
                      <CyberButton variant="yellow" size="small" onClick={() => handleEditClick(q)}><EditIcon size={14} /></CyberButton>
                      <CyberButton variant="danger" size="small" onClick={() => handleDeleteClick(q.id)}><TrashIcon size={14} /></CyberButton>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CyberCard>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          TAB: CANDIDATES (updated: create + manage)
      ══════════════════════════════════════════════════════════════════════ */}
      {activeTab === "candidates" && (
        <div style={{ display:"flex", flexDirection:"column", gap:"24px" }}>
          {/* Create Candidate Form */}
          <CyberCard glowColor="cyan" title="REGISTER NEW CANDIDATE" subtitle="CREATE CANDIDATE ACCOUNT">
            <form onSubmit={handleCreateCandidate} style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
              {candError && (
                <div style={{ padding:"8px", background:"rgba(255,0,127,0.1)", border:"1px solid var(--neon-pink)",
                  color:"var(--neon-pink)", borderRadius:"4px", fontFamily:"var(--font-mono)", fontSize:"0.8rem" }}>
                  {candError}
                </div>
              )}
              {candMsg && (
                <div style={{ padding:"8px", background:"rgba(57,255,20,0.1)", border:"1px solid var(--neon-green)",
                  color:"var(--neon-green)", borderRadius:"4px", fontFamily:"var(--font-mono)", fontSize:"0.8rem" }}>
                  {candMsg}
                </div>
              )}
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:"12px" }}>
                <div>
                  <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"6px" }}>CODENAME</label>
                  <input type="text" className="cyber-input" value={newCandName}
                    onChange={(e) => setNewCandName(e.target.value.replace(/[^a-zA-Z0-9_]/g, "").toUpperCase())}
                    placeholder="e.g. NEO_RUNNER" maxLength={15} />
                </div>
                <div>
                  <label className="cyber-label" style={{ fontSize:"0.75rem", display:"block", marginBottom:"6px" }}>PASSWORD</label>
                  <input type="password" className="cyber-input" value={newCandPassword}
                    onChange={(e) => setNewCandPassword(e.target.value)} placeholder="••••••" />
                </div>
              </div>
              <CyberButton variant="success" type="submit">
                <span style={{ display:"inline-flex", alignItems:"center", gap:"8px" }}>
                  <UserIcon size={14} />
                  REGISTER CANDIDATE
                </span>
              </CyberButton>
            </form>
          </CyberCard>

          {/* Candidate List */}
          <CyberCard glowColor="purple" title="CANDIDATE ACCOUNTS" subtitle={`${candidates.length} REGISTERED CANDIDATES`}>
            {candidates.length === 0 ? (
              <div style={{ textAlign:"center", padding:"40px", color:"var(--text-muted)", fontFamily:"var(--font-mono)" }}>[ NO CANDIDATES FOUND ]</div>
            ) : (
              <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
                {candidates.map((c) => {
                  const runs = candidateMap[c.name.toUpperCase()] || [];
                  const best  = runs.length ? Math.max(...runs.map((r) => r.score)) : 0;
                  const avg   = runs.length ? Math.round(runs.reduce((a,r) => a+r.score, 0) / runs.length) : 0;
                  const rank = best === 100 ? "ARCH-NETRUNNER" : best >= 80 ? "CYBER-KNIGHT" : best >= 60 ? "GRID-OPERATIVE" : best >= 40 ? "SYS_INITIATE" : "CODE-MONKEY";
                  const rankColor = best === 100 ? "var(--neon-green)" : best >= 80 ? "var(--neon-cyan)" : best >= 60 ? "var(--neon-yellow)" : best >= 40 ? "var(--neon-purple)" : "var(--neon-pink)";

                  return (
                    <div key={c.name} style={{ background:"rgba(0,0,0,0.25)", border:"1px solid rgba(0,242,254,0.08)",
                      borderRadius:"8px", padding:"20px", display:"flex", justifyContent:"space-between",
                      alignItems:"center", gap:"16px", flexWrap:"wrap" }}
                      onMouseEnter={(e) => (e.currentTarget.style.borderColor = "rgba(0,242,254,0.25)")}
                      onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(0,242,254,0.08)")}>
                      <div style={{ display:"flex", alignItems:"center", gap:"16px" }}>
                        <div style={{ width:"44px", height:"44px", borderRadius:"50%",
                          background:"rgba(0,242,254,0.08)", border:"1px solid rgba(0,242,254,0.2)",
                          display:"flex", justifyContent:"center", alignItems:"center", color:"var(--neon-cyan)" }}>
                          <UserIcon size={20} />
                        </div>
                        <div>
                          <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                            <span style={{ fontFamily:"var(--font-display)", fontSize:"1rem", color:"#fff", fontWeight:"bold" }}>{c.name}</span>
                            {runs.length > 0 && (
                              <span className="cyber-badge" style={{ fontSize:"0.6rem", padding:"1px 5px",
                                background:`${rankColor}18`, color:rankColor, border:`1px solid ${rankColor}44` }}>{rank}</span>
                            )}
                          </div>
                          <div style={{ display:"flex", gap:"16px", marginTop:"6px", fontFamily:"var(--font-mono)", fontSize:"0.75rem", color:"var(--text-secondary)" }}>
                            <span>ATTEMPTS: <strong style={{ color:"#fff" }}>{runs.length}</strong></span>
                            {runs.length > 0 && (
                              <>
                                <span>BEST: <strong style={{ color:rankColor }}>{best}%</strong></span>
                                <span>AVG: <strong style={{ color:"var(--neon-cyan)" }}>{avg}%</strong></span>
                              </>
                            )}
                            <span>CREATED: <strong style={{ color:"var(--text-muted)" }}>{new Date(c.createdAt).toLocaleDateString()}</strong></span>
                          </div>
                        </div>
                      </div>
                      <CyberButton variant="danger" size="small" onClick={() => handleDeleteCandidate(c.name)}>
                        <TrashIcon size={14} />
                        <span style={{ marginLeft:"6px" }}>DELETE ACCOUNT</span>
                      </CyberButton>
                    </div>
                  );
                })}
              </div>
            )}
          </CyberCard>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          TAB: SETTINGS (simplified — no more local pw change)
      ══════════════════════════════════════════════════════════════════════ */}
      {activeTab === "settings" && (
        <CyberCard glowColor="cyan" title="SYSTEM INFORMATION" subtitle="CURRENT RUNTIME STATUS">
          <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
            {[
              { label:"DATABASE",    value:"MongoDB Atlas" },
              { label:"QUESTIONS",   value:`${questions.length} active nodes` },
              { label:"SESSIONS",    value:`${results.length} logged` },
              { label:"CANDIDATES",  value:`${candidates.length} registered` },
              { label:"APP_VERSION", value:"v1.0.0" },
              { label:"FRAMEWORK",   value:"Next.js 16.2.9" },
            ].map(({ label, value }) => (
              <div key={label} style={{ display:"flex", justifyContent:"space-between", borderBottom:"1px solid rgba(255,255,255,0.04)", paddingBottom:"10px" }}>
                <span className="cyber-label" style={{ fontSize:"0.7rem" }}>{label}</span>
                <span style={{ fontFamily:"var(--font-mono)", fontSize:"0.8rem", color:"#fff" }}>{value}</span>
              </div>
            ))}
            <CyberButton variant="danger" size="small" onClick={handleResetSystem} style={{ marginTop:"8px" }}>
              WIPE ALL DATA
            </CyberButton>
          </div>
        </CyberCard>
      )}
    </div>
  );
}
