import { NextRequest } from "next/server";
import { connectDB } from "@/lib/mongoose";
import { QuizResultModel } from "@/lib/models/QuizResult";

export async function GET() {
  try {
    await connectDB();
    const results = await QuizResultModel.find().sort({ _id: 1 }).lean();
    return Response.json(results);
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    const body: {
      candidateName: string;
      score: number;
      totalQuestions: number;
      correctAnswersCount: number;
      timeTakenSeconds: number;
    } = await request.json();

    const newResult = await QuizResultModel.create({
      id: "res_" + Math.random().toString(36).substring(2, 11),
      ...body,
      timestamp: new Date().toISOString(),
    });

    return Response.json(newResult);
  } catch {
    return Response.json({ error: "Failed to save result" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    const candidate = request.nextUrl.searchParams.get("candidate");
    if (candidate) {
      await QuizResultModel.deleteMany({
        candidateName: { $regex: new RegExp(`^${escapeRegex(candidate)}$`, "i") },
      });
    } else {
      await QuizResultModel.deleteMany({});
    }
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: "Failed to delete results" }, { status: 500 });
  }
}

function escapeRegex(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
