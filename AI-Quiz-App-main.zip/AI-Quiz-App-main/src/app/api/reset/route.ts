import { connectDB } from "@/lib/mongoose";
import { QuestionModel } from "@/lib/models/Question";
import { QuizResultModel } from "@/lib/models/QuizResult";

export async function POST() {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    await QuestionModel.deleteMany({});
    await QuizResultModel.deleteMany({});
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: "Failed to reset" }, { status: 500 });
  }
}
