import { NextRequest } from "next/server";
import { connectDB } from "@/lib/mongoose";
import { CandidateModel } from "@/lib/models/Candidate";
import { verifyPassword } from "@/lib/auth";

// POST /api/auth/candidate — validate candidate credentials
export async function POST(request: NextRequest) {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    const { name, password } = await request.json();

    if (!name || !password) {
      return Response.json({ error: "Name and password required" }, { status: 400 });
    }

    const candidate = await CandidateModel.findOne({
      name: { $regex: new RegExp(`^${escapeRegex(name)}$`, "i") },
      isActive: true,
    });

    if (!candidate || !verifyPassword(password, candidate.passwordHash)) {
      return Response.json({ error: "Invalid credentials" }, { status: 401 });
    }

    return Response.json({ success: true, name: candidate.name });
  } catch {
    return Response.json({ error: "Server error" }, { status: 500 });
  }
}

function escapeRegex(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
