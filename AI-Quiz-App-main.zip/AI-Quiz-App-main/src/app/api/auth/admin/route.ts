import { NextRequest } from "next/server";
import { connectDB } from "@/lib/mongoose";
import { AdminModel } from "@/lib/models/Admin";
import { hashPassword, verifyPassword } from "@/lib/auth";

// GET /api/auth/admin — check if any admin exists
export async function GET() {
  try {
    await connectDB();
    const count = await AdminModel.countDocuments();
    return Response.json({ adminExists: count > 0 });
  } catch {
    return Response.json({ adminExists: false }, { status: 500 });
  }
}

// POST /api/auth/admin — register first admin or login
export async function POST(request: NextRequest) {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    const { action, username, password } = await request.json();

    if (action === "register") {
      const existingCount = await AdminModel.countDocuments();
      if (existingCount > 0) {
        return Response.json({ error: "Admin already exists" }, { status: 403 });
      }
      if (!username || !password) {
        return Response.json({ error: "Username and password required" }, { status: 400 });
      }
      if (password.length < 4) {
        return Response.json({ error: "Password must be at least 4 characters" }, { status: 400 });
      }

      const passwordHash = hashPassword(password);
      await AdminModel.create({ username, passwordHash });
      return Response.json({ success: true });
    }

    if (action === "login") {
      if (!username || !password) {
        return Response.json({ error: "Username and password required" }, { status: 400 });
      }

      const admin = await AdminModel.findOne({ username });
      if (!admin || !verifyPassword(password, admin.passwordHash)) {
        return Response.json({ error: "Invalid credentials" }, { status: 401 });
      }

      return Response.json({ success: true, username: admin.username });
    }

    return Response.json({ error: "Invalid action" }, { status: 400 });
  } catch {
    return Response.json({ error: "Server error" }, { status: 500 });
  }
}
