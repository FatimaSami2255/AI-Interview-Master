import { NextRequest } from "next/server";
import { connectDB } from "@/lib/mongoose";
import { QuestionModel } from "@/lib/models/Question";
import type { Question } from "@/lib/types";

export async function GET() {
  try {
    await connectDB();
    const questions = await QuestionModel.find().sort({ _id: 1 }).lean();
    return Response.json(questions);
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    const body: Question = await request.json();
    const existing = await QuestionModel.findOne({ id: body.id });

    if (existing) {
      await QuestionModel.updateOne({ id: body.id }, { $set: body as any });
    } else {
      await QuestionModel.create(body as any);
    }

    const question = await QuestionModel.findOne({ id: body.id }).lean();
    return Response.json(question);
  } catch {
    return Response.json({ error: "Failed to save question" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    const id = request.nextUrl.searchParams.get("id");
    if (!id) {
      return Response.json({ error: "Missing ?id parameter" }, { status: 400 });
    }
    await QuestionModel.deleteOne({ id });
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: "Failed to delete question" }, { status: 500 });
  }
}
