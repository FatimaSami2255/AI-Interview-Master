import { NextRequest } from "next/server";
import { connectDB } from "@/lib/mongoose";
import { CandidateModel } from "@/lib/models/Candidate";
import { hashPassword } from "@/lib/auth";

// GET /api/candidates — list all candidates
export async function GET() {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    const candidates = await CandidateModel.find()
      .select("name isActive createdAt")
      .sort({ createdAt: -1 })
      .lean();
    return Response.json(candidates);
  } catch {
    return Response.json({ error: "Failed to fetch candidates" }, { status: 500 });
  }
}

// POST /api/candidates — create a new candidate (admin only)
export async function POST(request: NextRequest) {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    const { name, password } = await request.json();

    if (!name || !password) {
      return Response.json({ error: "Name and password required" }, { status: 400 });
    }
    if (name.length < 3 || name.length > 15) {
      return Response.json({ error: "Name must be 3-15 characters" }, { status: 400 });
    }
    if (password.length < 4) {
      return Response.json({ error: "Password must be at least 4 characters" }, { status: 400 });
    }

    const existing = await CandidateModel.findOne({
      name: { $regex: new RegExp(`^${escapeRegex(name)}$`, "i") },
    });
    if (existing) {
      return Response.json({ error: "Candidate with that name already exists" }, { status: 409 });
    }

    const passwordHash = hashPassword(password);
    const candidate = await CandidateModel.create({ name, passwordHash });
    return Response.json({ success: true, name: candidate.name });
  } catch {
    return Response.json({ error: "Failed to create candidate" }, { status: 500 });
  }
}

// DELETE /api/candidates?name=NAME — delete a candidate
export async function DELETE(request: NextRequest) {
  try {
    await connectDB();
  } catch {
    return Response.json({ error: "Database offline" }, { status: 503 });
  }

  try {
    const name = request.nextUrl.searchParams.get("name");
    if (!name) {
      return Response.json({ error: "Missing ?name parameter" }, { status: 400 });
    }

    await CandidateModel.deleteOne({
      name: { $regex: new RegExp(`^${escapeRegex(name)}$`, "i") },
    });
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: "Failed to delete candidate" }, { status: 500 });
  }
}

function escapeRegex(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
