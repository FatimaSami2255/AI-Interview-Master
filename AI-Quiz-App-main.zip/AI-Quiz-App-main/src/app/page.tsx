"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { CyberCard } from "@/components/CyberCard";
import { CyberButton } from "@/components/CyberButton";
import { getQuestions, getQuizResults } from "@/lib/storage";

export default function Home() {
  const [stats, setStats] = useState({
    totalQuestions: 0,
    totalAttempts: 0,
    topScore: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const questions = await getQuestions();
        const results = await getQuizResults();
        
        const maxScore = results.length > 0 ? Math.max(...results.map(r => r.score)) : 0;
        
        setStats({
          totalQuestions: questions.length,
          totalAttempts: results.length,
          topScore: maxScore,
        });
      } catch (err) {
        console.error(err);
      }
    };
    fetchStats();
  }, []);

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        minHeight: "calc(100vh - 73px)", // Subtract header height
        padding: "40px 24px",
        position: "relative",
      }}
      className="grid-scan"
    >
      {/* Decorative Matrix/Neon Background Glows */}
      <div
        style={{
          position: "absolute",
          top: "10%",
          left: "20%",
          width: "250px",
          height: "250px",
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(0, 242, 254, 0.08) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: "15%",
          right: "20%",
          width: "300px",
          height: "300px",
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(157, 78, 221, 0.08) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      {/* Main Terminal Shell */}
      <div style={{ maxWidth: "800px", width: "100%", zIndex: 10 }}>
        {/* Hologram Header */}
        <div style={{ textAlign: "center", marginBottom: "48px" }}>
          <span
            className="cyber-label"
            style={{ fontSize: "0.8rem", textShadow: "var(--glow-cyan)" }}
          >
            [ SECURE SYSTEM INTERFACE ]
          </span>
          <h1
            className="glitch-title"
            style={{
              fontSize: "clamp(2rem, 5vw, 3.5rem)",
              fontFamily: "var(--font-display)",
              fontWeight: 900,
              textTransform: "uppercase",
              letterSpacing: "4px",
              marginTop: "12px",
              background: "linear-gradient(90deg, #fff 30%, var(--neon-cyan) 70%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            NEURAL_QUIZ
          </h1>
          <p
            style={{
              color: "var(--text-secondary)",
              maxWidth: "500px",
              margin: "16px auto 0",
              fontSize: "1rem",
              lineHeight: "1.6",
            }}
          >
            Welcome to the advanced knowledge evaluation grid. Authenticate your credentials below to access candidate testing or network logs.
          </p>
        </div>

        {/* Action Gateways */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: "24px",
            marginBottom: "48px",
          }}
        >
          {/* Candidate Card */}
          <CyberCard
            glowColor="cyan"
            title="CANDIDATE EXAM GRID"
            subtitle="ACCESS INTERACTIVE QUZZES"
          >
            <div style={{ minHeight: "130px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
              <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", lineHeight: "1.6" }}>
                Enter the evaluation arena. Test your skills across 10 random topics. Features automated countdown timers, detailed analytics, and active scoreboards.
              </p>
              <div style={{ marginTop: "24px" }}>
                <Link href="/quiz">
                  <CyberButton variant="primary" style={{ width: "100%" }}>
                    LAUNCH EXAM_GRID
                  </CyberButton>
                </Link>
              </div>
            </div>
          </CyberCard>

          {/* Admin Card */}
          <CyberCard
            glowColor="purple"
            title="ADMIN CONTROL PANEL"
            subtitle="MANAGE QUESTION BANK & LOGS"
          >
            <div style={{ minHeight: "130px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
              <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", lineHeight: "1.6" }}>
                Access security logs. Add, edit, or purge evaluation questions. Analyze live candidate response metrics, scores, and exam speed records.
              </p>
              <div style={{ marginTop: "24px" }}>
                <Link href="/admin">
                  <CyberButton variant="secondary" style={{ width: "100%" }}>
                    ACCESS TERMINAL
                  </CyberButton>
                </Link>
              </div>
            </div>
          </CyberCard>
        </div>

        {/* System Diagnostics Footer */}
        <CyberCard glowColor="green" scanline={true} style={{ padding: "16px 20px" }}>
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              alignItems: "center",
              gap: "20px",
              textAlign: "center",
            }}
          >
            <div>
              <span className="cyber-label" style={{ display: "block", fontSize: "0.7rem", color: "var(--text-secondary)" }}>
                DATABASE_STATUS
              </span>
              <span style={{ fontFamily: "var(--font-mono)", color: "var(--neon-green)", fontSize: "0.95rem" }}>
                ONLINE [MONGODB]
              </span>
            </div>
            <div
              style={{
                width: "1px",
                height: "24px",
                background: "rgba(255,255,255,0.08)",
                display: "inline-block",
              }}
            />
            <div>
              <span className="cyber-label" style={{ display: "block", fontSize: "0.7rem", color: "var(--text-secondary)" }}>
                TOTAL_QUESTIONS
              </span>
              <span style={{ fontFamily: "var(--font-mono)", color: "#fff", fontSize: "0.95rem" }}>
                {stats.totalQuestions} ITEMS
              </span>
            </div>
            <div
              style={{
                width: "1px",
                height: "24px",
                background: "rgba(255,255,255,0.08)",
                display: "inline-block",
              }}
            />
            <div>
              <span className="cyber-label" style={{ display: "block", fontSize: "0.7rem", color: "var(--text-secondary)" }}>
                COMPLETED_TESTS
              </span>
              <span style={{ fontFamily: "var(--font-mono)", color: "#fff", fontSize: "0.95rem" }}>
                {stats.totalAttempts} SESSIONS
              </span>
            </div>
            <div
              style={{
                width: "1px",
                height: "24px",
                background: "rgba(255,255,255,0.08)",
                display: "inline-block",
              }}
            />
            <div>
              <span className="cyber-label" style={{ display: "block", fontSize: "0.7rem", color: "var(--text-secondary)" }}>
                TOP_GRID_SCORE
              </span>
              <span style={{ fontFamily: "var(--font-mono)", color: "var(--neon-cyan)", fontSize: "0.95rem" }}>
                {stats.topScore}% ACCURACY
              </span>
            </div>
          </div>
        </CyberCard>
      </div>
    </div>
  );
}
