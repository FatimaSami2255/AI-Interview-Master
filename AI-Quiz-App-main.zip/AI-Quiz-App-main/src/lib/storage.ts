import { Question, QuizResult } from "./types";

const BASE = "/api";

// ─── Admin Auth ──────────────────────────────────────────────────────────────
export const checkAdminExists = async (): Promise<boolean> => {
  const res = await fetch(`${BASE}/auth/admin`);
  if (!res.ok) throw new Error("Failed to check admin status");
  const data = await res.json();
  return data.adminExists;
};

export const registerAdmin = async (username: string, password: string): Promise<void> => {
  const res = await fetch(`${BASE}/auth/admin`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "register", username, password }),
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || "Registration failed");
  }
};

export const loginAdmin = async (username: string, password: string): Promise<void> => {
  const res = await fetch(`${BASE}/auth/admin`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "login", username, password }),
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || "Login failed");
  }
};

// ─── Candidate Auth ──────────────────────────────────────────────────────────
export const loginCandidate = async (name: string, password: string): Promise<string> => {
  const res = await fetch(`${BASE}/auth/candidate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, password }),
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || "Login failed");
  }
  const data = await res.json();
  return data.name;
};

// ─── Candidate Management (admin) ────────────────────────────────────────────
export const getCandidates = async (): Promise<{ name: string; isActive: boolean; createdAt: string }[]> => {
  const res = await fetch(`${BASE}/candidates`);
  if (!res.ok) throw new Error("Failed to fetch candidates");
  return res.json();
};

export const createCandidate = async (name: string, password: string): Promise<void> => {
  const res = await fetch(`${BASE}/candidates`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, password }),
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || "Failed to create candidate");
  }
};

export const deleteCandidate = async (name: string): Promise<void> => {
  const res = await fetch(`${BASE}/candidates?name=${encodeURIComponent(name)}`, {
    method: "DELETE",
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data.error || "Failed to delete candidate");
  }
};

// ─── Questions ───────────────────────────────────────────────────────────────
export const getQuestions = async (): Promise<Question[]> => {
  const res = await fetch(`${BASE}/questions`);
  if (!res.ok) throw new Error("Failed to fetch questions");
  return res.json();
};

export const saveQuestion = async (question: Question): Promise<Question> => {
  const res = await fetch(`${BASE}/questions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(question),
  });
  if (!res.ok) throw new Error("Failed to save question");
  return res.json();
};

export const deleteQuestion = async (id: string): Promise<boolean> => {
  const res = await fetch(`${BASE}/questions?id=${encodeURIComponent(id)}`, {
    method: "DELETE",
  });
  if (!res.ok) throw new Error("Failed to delete question");
  return true;
};

export const getRandomQuestionsForQuiz = async (difficulty?: string): Promise<Question[]> => {
  const allQuestions = await getQuestions();
  let filtered = allQuestions;
  if (difficulty && difficulty !== "All") {
    filtered = allQuestions.filter(
      (q) => q.difficulty.toLowerCase() === difficulty.toLowerCase()
    );
  }
  const shuffled = [...filtered];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled.slice(0, Math.min(10, shuffled.length));
};

// ─── Quiz Results ────────────────────────────────────────────────────────────
export const getQuizResults = async (): Promise<QuizResult[]> => {
  const res = await fetch(`${BASE}/results`);
  if (!res.ok) throw new Error("Failed to fetch results");
  return res.json();
};

export const saveQuizResult = async (
  result: Omit<QuizResult, "id" | "timestamp">
): Promise<QuizResult> => {
  const res = await fetch(`${BASE}/results`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(result),
  });
  if (!res.ok) throw new Error("Failed to save quiz result");
  return res.json();
};

export const resetToDefaults = async (): Promise<boolean> => {
  const res = await fetch(`${BASE}/reset`, { method: "POST" });
  if (!res.ok) throw new Error("Failed to reset");
  return true;
};

export const deleteCandidateResults = async (candidateName: string): Promise<boolean> => {
  const res = await fetch(
    `${BASE}/results?candidate=${encodeURIComponent(candidateName)}`,
    { method: "DELETE" }
  );
  if (!res.ok) throw new Error("Failed to purge candidate results");
  return true;
};
