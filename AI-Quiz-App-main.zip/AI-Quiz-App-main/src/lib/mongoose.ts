import mongoose from "mongoose";

const MONGO_URI = process.env.MONGO_URI!;

if (!MONGO_URI) {
  throw new Error("Please define the MONGO_URI environment variable in .env");
}

// Extend global to cache connection across hot-reloads in dev
declare global {
  // eslint-disable-next-line no-var
  var _mongooseConn: typeof mongoose | null;
  // eslint-disable-next-line no-var
  var _mongoosePromise: Promise<typeof mongoose> | null;
}

let cached = global._mongooseConn;
let cachedPromise = global._mongoosePromise;

export async function connectDB(): Promise<typeof mongoose> {
  if (cached) return cached;

  if (!cachedPromise) {
    cachedPromise = mongoose.connect(MONGO_URI, {
      bufferCommands: false,
    });
    global._mongoosePromise = cachedPromise;
  }

  try {
    cached = await cachedPromise;
    global._mongooseConn = cached;
    return cached;
  } catch (e) {
    global._mongoosePromise = null;
    throw e;
  }
}
