import mongoose, { Schema, model, models } from "mongoose";

const QuizResultSchema = new Schema(
  {
    id: { type: String, required: true, unique: true },
    candidateName: { type: String, required: true },
    score: { type: Number, required: true },
    totalQuestions: { type: Number, required: true },
    correctAnswersCount: { type: Number, required: true },
    timeTakenSeconds: { type: Number, required: true },
    timestamp: { type: String, required: true },
  },
  { timestamps: true }
);

export const QuizResultModel =
  (models.QuizResult as mongoose.Model<mongoose.InferSchemaType<typeof QuizResultSchema>>) ||
  model("QuizResult", QuizResultSchema);
