import mongoose, { Schema, model, models } from "mongoose";

const AdminSchema = new Schema(
  {
    username: { type: String, required: true, unique: true },
    passwordHash: { type: String, required: true },
  },
  { timestamps: true }
);

export const AdminModel =
  (models.Admin as mongoose.Model<mongoose.InferSchemaType<typeof AdminSchema>>) ||
  model("Admin", AdminSchema);
