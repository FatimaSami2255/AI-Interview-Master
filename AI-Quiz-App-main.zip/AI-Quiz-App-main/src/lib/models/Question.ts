import mongoose, { Schema, model, models } from "mongoose";

const QuestionSchema = new Schema(
  {
    id: { type: String, required: true, unique: true },
    text: { type: String, required: true },
    options: { type: [String], required: true },
    correctOptionIndex: { type: Number, required: true },
    difficulty: { type: String, enum: ["Easy", "Medium", "Hard"], required: true },
    category: { type: String, required: true },
    explanation: { type: String, default: "" },
  },
  { timestamps: true }
);

export const QuestionModel =
  (models.Question as mongoose.Model<mongoose.InferSchemaType<typeof QuestionSchema>>) ||
  model("Question", QuestionSchema);
