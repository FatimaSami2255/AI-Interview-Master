import mongoose, { Schema, model, models } from "mongoose";

const CandidateSchema = new Schema(
  {
    name: { type: String, required: true, unique: true },
    passwordHash: { type: String, required: true },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export const CandidateModel =
  (models.Candidate as mongoose.Model<mongoose.InferSchemaType<typeof CandidateSchema>>) ||
  model("Candidate", CandidateSchema);
