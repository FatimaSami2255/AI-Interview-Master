export type DifficultyLevel = "Easy" | "Medium" | "Hard";

export interface Question {
  id: string;
  text: string;
  options: [string, string, string, string]; // Exactly 4 options
  correctOptionIndex: number; // 0 to 3
  difficulty: DifficultyLevel;
  category: string;
  explanation: string;
}

export interface QuizResult {
  id: string;
  candidateName: string;
  score: number; // Percentage (e.g. 80)
  totalQuestions: number;
  correctAnswersCount: number;
  timeTakenSeconds: number;
  timestamp: string; // ISO string
}
