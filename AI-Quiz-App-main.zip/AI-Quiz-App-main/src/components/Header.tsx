"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { UserIcon, LockIcon } from "./SvgIcons";

export const Header: React.FC = () => {
  const pathname = usePathname();
  const [codename, setCodename] = useState<string | null>(null);

  useEffect(() => {
    // Check localStorage for registered candidate
    const updateCodename = () => {
      if (typeof window !== "undefined") {
        const stored = localStorage.getItem("cyber_candidate_name");
        setCodename(stored);
      }
    };

    updateCodename();

    // Listen to custom storage event or local updates
    window.addEventListener("storage", updateCodename);
    const interval = setInterval(updateCodename, 2000); // Poll occasionally for easy sync

    return () => {
      window.removeEventListener("storage", updateCodename);
      clearInterval(interval);
    };
  }, []);

  const isAdmin = pathname?.startsWith("/admin");
  const isQuiz = pathname?.startsWith("/quiz");

  return (
    <header
      style={{
        width: "100%",
        padding: "16px 24px",
        background: "rgba(5, 5, 8, 0.85)",
        borderBottom: "1px solid var(--border-neon)",
        backdropFilter: "blur(12px)",
        WebkitBackdropFilter: "blur(12px)",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        position: "sticky",
        top: 0,
        zIndex: 100,
        boxShadow: "0 4px 20px rgba(0, 0, 0, 0.4)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "24px" }}>
        {/* Futuristic Brand Logo */}
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <div
            style={{
              width: "10px",
              height: "10px",
              borderRadius: "50%",
              background: "var(--neon-cyan)",
              boxShadow: "var(--glow-cyan)",
            }}
          />
          <span
            className="glitch-title"
            style={{
              fontFamily: "var(--font-display)",
              fontWeight: 900,
              fontSize: "1.2rem",
              letterSpacing: "2px",
              color: "#fff",
            }}
          >
            CYBER_QUIZ <span style={{ color: "var(--neon-cyan)", fontSize: "0.8rem" }}>{"// V1.0"}</span>
          </span>
        </Link>

        {/* Navigation */}
        <nav style={{ display: "flex", gap: "16px" }}>
          <Link
            href="/quiz"
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "0.8rem",
              letterSpacing: "1px",
              color: isQuiz ? "var(--neon-cyan)" : "var(--text-secondary)",
              transition: "color var(--transition-fast)",
              display: "flex",
              alignItems: "center",
              gap: "6px",
              padding: "6px 12px",
              border: `1px solid ${isQuiz ? "rgba(0,242,254,0.2)" : "transparent"}`,
              borderRadius: "4px",
              background: isQuiz ? "rgba(0,242,254,0.05)" : "transparent",
            }}
          >
            <UserIcon size={14} />
            CANDIDATE_PORTAL
          </Link>
          <Link
            href="/admin"
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "0.8rem",
              letterSpacing: "1px",
              color: isAdmin ? "var(--neon-purple)" : "var(--text-secondary)",
              transition: "color var(--transition-fast)",
              display: "flex",
              alignItems: "center",
              gap: "6px",
              padding: "6px 12px",
              border: `1px solid ${isAdmin ? "rgba(157,78,221,0.2)" : "transparent"}`,
              borderRadius: "4px",
              background: isAdmin ? "rgba(157,78,221,0.05)" : "transparent",
            }}
          >
            <LockIcon size={14} />
            ADMIN_TERMINAL
          </Link>
        </nav>
      </div>

      {/* Stats / Status Badge */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        {isAdmin ? (
          <div
            className="cyber-badge"
            style={{
              border: "1px solid rgba(157,78,221,0.4)",
              background: "rgba(157,78,221,0.1)",
              color: "var(--neon-purple)",
              display: "flex",
              alignItems: "center",
              gap: "6px",
            }}
          >
            <span
              style={{
                width: "6px",
                height: "6px",
                borderRadius: "50%",
                background: "var(--neon-purple)",
                boxShadow: "var(--glow-purple)",
              }}
            />
            ROOT_ACCESS
          </div>
        ) : codename ? (
          <div
            className="cyber-badge"
            style={{
              border: "1px solid rgba(0,242,254,0.4)",
              background: "rgba(0,242,254,0.1)",
              color: "var(--neon-cyan)",
              display: "flex",
              alignItems: "center",
              gap: "6px",
            }}
          >
            <span
              style={{
                width: "6px",
                height: "6px",
                borderRadius: "50%",
                background: "var(--neon-green)",
                boxShadow: "var(--glow-green)",
              }}
            />
            CANDIDATE: {codename.toUpperCase()}
          </div>
        ) : (
          <div
            className="cyber-badge"
            style={{
              border: "1px solid var(--text-muted)",
              background: "rgba(255,255,255,0.02)",
              color: "var(--text-secondary)",
              display: "flex",
              alignItems: "center",
              gap: "6px",
            }}
          >
            <span
              style={{
                width: "6px",
                height: "6px",
                borderRadius: "50%",
                background: "var(--text-muted)",
              }}
            />
            STANDBY
          </div>
        )}
      </div>
    </header>
  );
};
export default Header;
