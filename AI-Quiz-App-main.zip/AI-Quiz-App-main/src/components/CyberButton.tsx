import React from "react";

interface CyberButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "danger" | "success" | "yellow";
  size?: "small" | "medium" | "large";
  sound?: boolean;
}

export const CyberButton: React.FC<CyberButtonProps> = ({
  variant = "primary",
  size = "medium",
  sound = true,
  children,
  className = "",
  style,
  onMouseEnter,
  onClick,
  ...props
}) => {
  // Safe synthesizer logic
  const playSfx = (type: "hover" | "click") => {
    if (!sound || typeof window === "undefined") return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      
      if (type === "hover") {
        // High frequency clean sine chirp
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(900, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1400, ctx.currentTime + 0.06);
        gain.gain.setValueAtTime(0.01, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.06);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.06);
      } else if (type === "click") {
        // Futuristic descending tone
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.03, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.12);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.12);
      }
    } catch {
      // Audio context blocked or unsupported
    }
  };

  const handleMouseEnter = (e: React.MouseEvent<HTMLButtonElement>) => {
    playSfx("hover");
    if (onMouseEnter) onMouseEnter(e);
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    playSfx("click");
    if (onClick) onClick(e);
  };

  // Resolve sizes
  const paddingMap = {
    small: "6px 12px",
    medium: "10px 20px",
    large: "14px 28px",
  };
  const fontSizeMap = {
    small: "0.75rem",
    medium: "0.875rem",
    large: "1rem",
  };

  // Color variants
  const colorMap = {
    primary: {
      color: "var(--neon-cyan)",
      border: "rgba(0, 242, 254, 0.3)",
      borderHover: "rgba(0, 242, 254, 1)",
      bg: "rgba(0, 242, 254, 0.04)",
      bgHover: "rgba(0, 242, 254, 0.15)",
      glow: "0 0 10px rgba(0, 242, 254, 0.2)",
      glowHover: "0 0 20px rgba(0, 242, 254, 0.5)",
    },
    secondary: {
      color: "var(--neon-purple)",
      border: "rgba(157, 78, 221, 0.3)",
      borderHover: "rgba(157, 78, 221, 1)",
      bg: "rgba(157, 78, 221, 0.04)",
      bgHover: "rgba(157, 78, 221, 0.15)",
      glow: "0 0 10px rgba(157, 78, 221, 0.2)",
      glowHover: "0 0 20px rgba(157, 78, 221, 0.5)",
    },
    danger: {
      color: "var(--neon-pink)",
      border: "rgba(255, 0, 127, 0.3)",
      borderHover: "rgba(255, 0, 127, 1)",
      bg: "rgba(255, 0, 127, 0.04)",
      bgHover: "rgba(255, 0, 127, 0.15)",
      glow: "0 0 10px rgba(255, 0, 127, 0.2)",
      glowHover: "0 0 20px rgba(255, 0, 127, 0.5)",
    },
    success: {
      color: "var(--neon-green)",
      border: "rgba(57, 255, 20, 0.3)",
      borderHover: "rgba(57, 255, 20, 1)",
      bg: "rgba(57, 255, 20, 0.04)",
      bgHover: "rgba(57, 255, 20, 0.15)",
      glow: "0 0 10px rgba(57, 255, 20, 0.2)",
      glowHover: "0 0 20px rgba(57, 255, 20, 0.5)",
    },
    yellow: {
      color: "var(--neon-yellow)",
      border: "rgba(255, 251, 0, 0.3)",
      borderHover: "rgba(255, 251, 0, 1)",
      bg: "rgba(255, 251, 0, 0.04)",
      bgHover: "rgba(255, 251, 0, 0.15)",
      glow: "0 0 10px rgba(255, 251, 0, 0.2)",
      glowHover: "0 0 20px rgba(255, 251, 0, 0.5)",
    },
  };

  const scheme = colorMap[variant];

  const buttonStyle: React.CSSProperties = {
    fontFamily: "var(--font-display)",
    fontSize: fontSizeMap[size],
    padding: paddingMap[size],
    color: scheme.color,
    background: scheme.bg,
    border: `1px solid ${scheme.border}`,
    borderRadius: "4px",
    cursor: props.disabled ? "not-allowed" : "pointer",
    textTransform: "uppercase",
    letterSpacing: "1.5px",
    fontWeight: "bold",
    outline: "none",
    position: "relative",
    overflow: "hidden",
    boxShadow: scheme.glow,
    transition: "all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1)",
    opacity: props.disabled ? 0.5 : 1,
    ...style,
  };

  return (
    <button
      className={`cyber-button-inner ${className}`}
      style={buttonStyle}
      onMouseEnter={handleMouseEnter}
      onClick={handleClick}
      {...props}
    >
      {/* Decorative inner left border line */}
      <span
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          bottom: 0,
          width: "2px",
          background: scheme.color,
        }}
      />

      <span style={{ position: "relative", zIndex: 2 }}>{children}</span>

      <style jsx>{`
        .cyber-button-inner:hover:not(:disabled) {
          background: ${scheme.bgHover} !important;
          border-color: ${scheme.borderHover} !important;
          box-shadow: ${scheme.glowHover} !important;
          text-shadow: 0 0 5px ${scheme.color};
          transform: scale(1.02);
        }
        .cyber-button-inner:active:not(:disabled) {
          transform: scale(0.98);
        }
      `}</style>
    </button>
  );
};
