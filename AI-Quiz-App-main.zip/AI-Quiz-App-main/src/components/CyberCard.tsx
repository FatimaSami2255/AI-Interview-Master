import React from "react";

interface CyberCardProps extends React.HTMLAttributes<HTMLDivElement> {
  glowColor?: "cyan" | "purple" | "pink" | "green" | "yellow";
  title?: string;
  subtitle?: string;
  scanline?: boolean;
}

export const CyberCard: React.FC<CyberCardProps> = ({
  glowColor = "cyan",
  title,
  subtitle,
  scanline = false,
  children,
  className = "",
  style,
  ...props
}) => {
  // Determine shadow and border colors based on theme choice
  const themeColors = {
    cyan: "var(--neon-cyan)",
    purple: "var(--neon-purple)",
    pink: "var(--neon-pink)",
    green: "var(--neon-green)",
    yellow: "var(--neon-yellow)",
  };

  const selectedColor = themeColors[glowColor];

  const cardStyle: React.CSSProperties = {
    position: "relative",
    padding: "24px",
    background: "var(--bg-card)",
    backdropFilter: "blur(12px)",
    WebkitBackdropFilter: "blur(12px)",
    border: `1px solid rgba(255, 255, 255, 0.05)`,
    borderLeft: `3px solid ${selectedColor}`,
    borderRadius: "8px",
    boxShadow: `0 8px 32px 0 rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.2) 0px 0px 10px`,
    overflow: "hidden",
    transition: "transform 0.3s cubic-bezier(0.25, 0.8, 0.25, 1), border-color 0.3s, box-shadow 0.3s",
    ...style,
  };

  return (
    <div
      style={cardStyle}
      className={`cyber-card-outer ${className} ${scanline ? "grid-scan" : ""}`}
      {...props}
    >
      {/* Sci-fi Decorative Corner Clip */}
      <div
        style={{
          position: "absolute",
          top: 0,
          right: 0,
          width: "12px",
          height: "12px",
          background: selectedColor,
          clipPath: "polygon(100% 0, 0 0, 100% 100%)",
          opacity: 0.8,
        }}
      />

      {/* Cybernetic Accent Bar bottom-left */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: "24px",
          width: "40px",
          height: "2px",
          background: selectedColor,
          opacity: 0.6,
        }}
      />

      {(title || subtitle) && (
        <div style={{ marginBottom: "20px", borderBottom: "1px solid rgba(255,255,255,0.05)", paddingBottom: "12px" }}>
          {title && (
            <h3 style={{ textTransform: "uppercase", fontSize: "1.2rem", fontWeight: 700, letterSpacing: "1px" }}>
              {title}
            </h3>
          )}
          {subtitle && (
            <span className="cyber-label" style={{ fontSize: "0.75rem", display: "block", marginTop: "4px" }}>
              {subtitle}
            </span>
          )}
        </div>
      )}

      <div style={{ position: "relative", zIndex: 2 }}>{children}</div>

      <style jsx>{`
        .cyber-card-outer:hover {
          transform: translateY(-2px);
          border-color: rgba(255, 255, 255, 0.15) !important;
          box-shadow: 0 12px 40px 0 rgba(0, 0, 0, 0.5), ${selectedColor}22 0px 0px 25px !important;
        }
      `}</style>
    </div>
  );
};
